
<style>
    .footer {
    padding-top: 2rem;
    /* background: linear-gradient(
45deg, #110a0a 10%, #a84242 90%); */
background-color: #161d24;
    /* background: url(images/t_bannar_bg.jpg) rgb(93 57 57 / 50%); */
    /* background-blend-mode: overlay; */
}
.footer p {
    font-size: 0.8rem;
    line-height: 1.5rem;
    color: #fff;
}
.footer h4 {
    color: unset;
}
.footer .ftr-main {
    border-bottom: 1px solid #fff;
}
.footer h4 {
    margin-bottom: 0.75rem;
    color: #fff;
}
.footer ul li {
    list-style: none;
}
.img-fluid {
    /* max-width: 100%; */
    height: auto;
    background-color: white;
    padding: 6px;
    width: 240px;
}
.footer ul li a {
    font-size: 0.8rem;
    line-height: 1.5rem;
    color: #fff;
    text-decoration: none;
}
.social-media {
    display: flex;
}
.social-media li{
    margin:10px;
}
.textwidget ul li
{
 padding: 5px; 
}
.textwidget ul li a:hover{
  color:#d93e3e;
 
 }
 /* .menu-footer-container  a:hover{
     border-bottom:2px solid #d93e3e;
     color:#d93e3e;
 } */
 a, a > .hover-1 {
  position: relative;
  color: inherit;
  text-decoration: none;
  line-height: 24px;
}
a:before, a:after {
  content: '';
  position: absolute;
  transition: transform .5s ease;
}
.hover-1{
  padding-top: 10px;
}
.hover-1:before {
    left: 0;
    bottom: 0;
    width: 100%;
    height: 2px;
    background: #ed4646;
    transform: scaleX(0);
}
.hover-1:hover:before {
  transform: scaleX(1);
}
.col-lg-6.col-12.col-sm-12.copy-right {
    text-align: end;
    margin-top: 15px;
}
    </style>
<section class="footer">
    <div class="container ">
        <div class="row ftr-main">
            <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 ftr-dscrp">
               <div class="widget_text widget widget_custom_html"><div class="widget_text widget-content"><div class="textwidget custom-html-widget"> <img src="images/Group 308.png" alt="" class="img-fluid" width="80%">
                <!-- <p>
                Welcome to IMF™ Trust. We are glad you have chosen us for your complete health needs and hope every encounter with our clinic and staff exceeds your expectations.
                </p> -->
            </div></div></div>            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12 footer-links">
                <h4>QUICK LINKS</h4>
                <div class="menu-footer-container">
                  <ul>
                    <li><a href="#" class="hover-1">Home</a></li>
                    <li><a href="#" class="hover-1">About us</a></li>
                    <li><a href="#" class="hover-1">Services</a></li>
                    <li><a href="#" class="hover-1">Volunteers</a></li>
                    <li><a href="#" class="hover-1">News</a></li>
                    <li><a href="#" class="hover-1">Contact</a></li>
                  
                </ul> 
            </div>
            </div>    
            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 address">
            <div class="widget_text widget widget_custom_html"><div class="widget_text widget-content"><div class="textwidget custom-html-widget"><h4>CONTACT US</h4>
                <p>#257, Bazaar street, <br>
                    (opp.Charminar st) 
             Pernambut<br>
                <i class="fa fa-envelope-o" aria-hidden="true"></i>&nbsp;imantrust21@gmail.com<br>
                <i class="fa fa-mobile" aria-hidden="true"></i>&nbsp; +91 9677463675</p></div></div></div>            </div>
            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3767.421918070801!2d73.09015311437891!3d19.220435352412395!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be795d0200cbee3%3A0x76469e1a3095786d!2sSAI%20ARCADE%20BUILDING!5e0!3m2!1sen!2sin!4v1611727910447!5m2!1sen!2sin" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
        </div>
        <div class="row pt-3">
            <div class="col-lg-6 col-12 col-sm-12 social-media">
                <!-- <ul>
                    <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                </ul> -->
                <div class="widget_text widget widget_custom_html">
                    <div class="widget_text widget-content">
                        <div class="textwidget">
                            <ul class="social-media">
                          <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </div>
    </div>         
   </div>
            <div class="col-lg-6 col-12 col-sm-12 copy-right">
                <p>&#169; 2021  - All rights reserved - IMF™ Trust</p>
            </div>

        </div>
    </div>
</section>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</body>
</html>