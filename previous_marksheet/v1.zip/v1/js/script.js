//script search box
$(function() {
    $('#searchlink').on('click', function(e) {
    	$(this).toggleClass('open');
    });
});