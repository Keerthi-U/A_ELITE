<?php

include_once('header.php');
?>
<link rel="stylesheet" href="style.css"> 

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Dosis:wght@200&family=IBM+Plex+Serif:wght@100&family=Josefin+Sans:ital@1&family=Lato&family=Libre+Baskerville&family=Open+Sans+Condensed:wght@300&family=Quicksand:wght@300&display=swap" rel="stylesheet">
<style>
  .col_content:hover{
    box-shadow: 0 0 25px -17px #000;
    border-bottom: solid #b1191a 2px;
  }
  .b_img:hover{
  opacity: 1;
	-webkit-transition: .3s ease-in-out;
	transition: .3s ease-in-out;
  }
   </style>

<div class="bg_img_sec">
        <!-- <div class="b_g_board">

        <div class="container"> -->
<!-- <div class="row align-items-end">
         <div class="col-md-4">
        <h2 data-animate-in="left" class="ab_head1">About us</h2>
      
         </div>
     </div>
</div> -->

        </div>
    </div>
<div class="container">
    <div class="about_bg">
        <div class="roww ">
        <div class="align-items-center">
            <div  data-animate-in="left" class="ab_im">
                <img src="images/ab_img2.jpg"  class="clip-polygon">
            </div>
        </div>
        
        <div class=" bdimgf_abus">
            <div data-animate-in="right" class="ab_content">
                <!-- <p class="ab_tit">Who we are</p> -->
                <h2  class="ab_head">About us</h2>
                <p class="ab_para">
                Welcome to the National Hookah Community Association "NHCA". We are a diverse alliance of businesses from all ends of the Hookah experience, from manufacturers and importers of molasses, pipes and accessories to distributors, Hookah lounges and Hookah/shisha retail stores.

                If you are a Hookah business, please join us and help us defend and protect your business, our culture and community.

                If you are an interested member of the public, welcome. Please enjoy learning about Hookah and its unique culture and practice.
                </p>
            </div>
        </div>
      </div>
   </div>
 </div>


 <div class="board_members">
     <div class="b_title">
         <h2>Board of Trustees</h2></div>
          <div class="row">
              <div class="coloums medium-3">
                   <div class="col_content">
                       <img src="images/j1.jpg" class="b_img">
                        <div class="pcw">

                        <div class="ab_overlay">
                          <strong  class="b_b">Sam R. Barnes
                        </strong><strong><br>
                        </strong><br>
                        <strong>Php Developer</strong>
                       <br><p class="l_text">  Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
                       </div>
                      </div>

                   </div>
              </div>

              <div class="coloums medium-3">
                   <div class="col_content">
                       <img src="images/j2.jpg" class="b_img">
                        <div class="pcw"><strong class="b_b">Deepika
                        </strong><strong><br>
                        </strong><br>
                        <strong>Php Developer</strong>
                       <br><p class="l_text">  Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
                      </div>

                   </div>
              </div>

              <div class="coloums medium-3">
                   <div class="col_content">
                       <img src="images/j3.jpg" class="b_img">
                        <div class="pcw"><strong class="b_b">Sam R. Barnes
                        </strong><strong>Chairperson<br>
                        </strong><br>
                        <strong>Php Developer</strong>
                       <br><p class="l_text">  Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
                      </div>

                   </div>
              </div>

              <div class="coloums medium-3">
                   <div class="col_content">
                       <img src="images/j6.jpg" class="b_img">
                        <div class="pcw"><strong class="b_b">Sam R. Barnes
                        </strong><strong><br>
                        </strong><br>
                        <strong>UI/UX Designer</strong>
                       <br><p class="l_text">  Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
                      </div>

                   </div>
              </div>

              <div class="coloums medium-3">
                   <div class="col_content">
                       <img src="images/j5.jpg" class="b_img">
                        <div class="pcw"><strong  class="b_b">Sam R. Barnes
                        </strong><strong><br>
                        </strong><br>
                        <strong>.Net Developer</strong>
                       <br><p class="l_text">  Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
                      </div>

                   </div>
              </div>

              <div class="coloums medium-3">
                   <div class="col_content">
                       <img src="images/j4.jpg" class="b_img">
                        <div class="pcw"><strong  class="b_b">Sam R. Barnes
                        </strong><strong><br>
                        </strong><br>
                        <strong>Php Developer</strong>
                       <br><p class="l_text">  Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
                      </div>

                   </div>
              </div>

          </div>
     
 </div>


 

<script>
    $(function() {
  
  var html = $('html');
  // Detections
  if (!("ontouchstart" in window)) {
    html.addClass("noTouch");
  }
  if ("ontouchstart" in window) {
    html.addClass("isTouch");
  }
  if ("ontouchstart" in window) {
    html.addClass("isTouch");
  }
  if (document.documentMode || /Edge/.test(navigator.userAgent)) {
    if (navigator.appVersion.indexOf("Trident") === -1) {
      html.addClass("isEDGE");
    } else {
      html.addClass("isIE isIE11");
    }
  }
  if (navigator.appVersion.indexOf("MSIE") !== -1) {
    html.addClass("isIE");
  }
  if (
    navigator.userAgent.indexOf("Safari") != -1 &&
    navigator.userAgent.indexOf("Chrome") == -1
  ) {
    html.addClass("isSafari");
  }

  // On Screen

  $.fn.isOnScreen = function() {
    var elementTop = $(this).offset().top,
      elementBottom = elementTop + $(this).outerHeight(),
      viewportTop = $(window).scrollTop(),
      viewportBottom = viewportTop + $(window).height();
    return elementBottom > viewportTop && elementTop < viewportBottom;
  };

  function detection() {
    for (var i = 0; i < items.length; i++) {
      var el = $(items[i]);

      if (el.isOnScreen()) {
        el.addClass("in-view");
      } else {
        el.removeClass("in-view");
      }
    }
  }

  var items = document.querySelectorAll(
    "*[data-animate-in], *[data-detect-viewport]"
  ),
    waiting = false,
    w = $(window);

  w.on("resize scroll", function() {
    if (waiting) {
      return;
    }
    waiting = true;
    detection();

    setTimeout(function() {
      waiting = false;
    }, 100);
  });

  $(document).ready(function() {
    setTimeout(function() {
      detection();
    }, 500);

    for (var i = 0; i < items.length; i++) {
      var d = 0,
        el = $(items[i]);
      if (items[i].getAttribute("data-animate-in-delay")) {
        d = items[i].getAttribute("data-animate-in-delay") / 2000 + "s";
      } else {
        d = 0;
      }
      el.css("transition-delay", d);
    }
  });
});

    </script>
<?php
include_once('footer.php');
?> 