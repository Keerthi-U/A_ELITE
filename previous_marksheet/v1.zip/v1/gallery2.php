<?php 
include_once('header.php');
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css" integrity="sha512-6lLUdeQ5uheMFbWm3CP271l14RsX1xtx+J5x2yeIDkkiBpeVTNhTqijME7GgRKKi6hCqovwCoBTlRBEC20M8Mg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css" integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
  
<style>
     .gallery-bg{
    background: url(images/wall-image.jpg) rgba(0, 0, 0, 0.5);
    background-blend-mode: overlay;
    height: 279px;

    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
    color: white;
    justify-content: cover;
    background-repeat: no-repeat;
    }
    .gellery-text {
    text-align: center;
    font-size: 28px;
    padding: 51px 0px 2px 0px;
    font-weight: 500;
    line-height: 1.2;
    color: #a18181;
    font-family:system-ui;}
.wrapper{
	width: 100%;

}


h1{
	font-family: "Trebuchet MS", Helvetica, sans-serif;
	font-size: 38px;
	text-align: center;
	
}




.tm-video-item figcaption, .tm-video-item figcaption > a {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
.tm-video-item figcaption {
    padding: 2em;
    color: #fff;
    text-transform: uppercase;
    font-size: 1.25em;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
}
.align-items-center {
    align-items: center!important;
}
 figcaption::before {
    position: absolute;
    top: 30px;
    right: 30px;
    bottom: 30px;
    left: 30px;
    border: 2px solid #fff;
    box-shadow: 0 0 0 30px rgb(255 255 255 / 20%);
    content: '';
    opacity: 0;
    -webkit-transition: opacity 0.35s, -webkit-transform 0.35s;
    transition: opacity 0.35s, transform 0.35s;
    -webkit-transform: scale3d(1.4,1.4,1);
    transform: scale3d(1.4,1.4,1);
}

.tm-video-item h2, .tm-video-item p {
    margin: 0;
}
.tm-video-item h2 {
    word-spacing: -0.15em;
    font-weight: 300;
}
.tm-video-item figcaption::before, .tm-video-item figcaption::after {
    pointer-events: none;
}
.tm-video-item figcaption > a {
    z-index: 1000;
    text-indent: 200%;
    white-space: nowrap;
    font-size: 0;
    opacity: 0;
}

/* .tm-video-item figcaption, .tm-video-item figcaption > a {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
} */
.tm-video-item figcaption, .tm-video-item figcaption > a {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
.photo-album:hover figcaption::before,
.photo-album:hover h2 {
	opacity: 1;
 

	-webkit-transform: scale3d(1,1,1);
	transform: scale3d(1,1,1);
}

.photo-album:hover figcaption { background-color: rgba(0, 0, 0, 0.5); }
/* .photo-album:hover img { opacity: 0.4; }   */
  figcaption {

}

figure.effect-ming {
    /* background: #030c17; */
    
}
figure:hover{
  /* background: #030c17; */
}


.figcaption2 {
  background: rgba(0, 0, 0, 0.5);
  color: white;
 
  padding: .2em 0;
  position: absolute;
  bottom: 0;
  text-align: center;
  width: 100%;
}

.figcaption2 span {
  font-size: 14px;
}

.figcaption3 {
  background: rgba(0, 0, 0, 0.5);
  color: white;
 
  padding: .2em 0;
  position: absolute;
  bottom: 0;
  text-align: center;
  width: 100%;
}

.figcaption3 span {
  font-size: 14px;
}
.figcaption4 {
  background: rgba(0, 0, 0, 0.5);
  color: white;
 
  padding: .2em 0;
  position: absolute;
  bottom: 0;
  text-align: center;
  width: 100%;
}

.figcaption4 span {
  font-size: 14px;
}


div#\#div2  {
    font-size: 16px;
    padding: 9px;
    color: white;
  
    text-transform: uppercase;
}
/* #menu:hover + .flyout {
    display: block;
} */
/* Media Queries */

@media screen and (min-width: 1024px){
	.wrapper{
		width: 90%;
		margin: 0 auto;
	}
}


/* slider css  */
.btn-danger {
  font-size: 16px;
}

.modal-backdrop.in {
  filter: alpha(opacity=80);
  opacity: .8;
}

.popup-image-gallery .modal-dialog {
  width: 100%;
}

.popup-image-gallery .modal-content {
  -webkit-box-shadow: none;
  box-shadow: none;
  background-color: transparent;
  border: 0;
  border-radius: 0;
}

.popup-slider-for {
  position: relative;
  min-height: 300px;
  z-index: 2;
}

@-webkit-keyframes spin {
  0% {
    -webkit-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}

@keyframes spin {
  0% {
    -webkit-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}

.popup-slider-for:after {
  content: "\e030";
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-animation: spin 1s linear infinite;
  animation: spin 1s linear infinite;
  z-index: -1;
  color: #fff;
  opacity: .75;
}

.popup-slider-for,
.main-image {
  text-align: center;
  margin-bottom: 0;
}

.popup-slider-for .slick-slide img {
  display: inline-block;
  max-width: 100%;
  vertical-align: middle;
}

.popup-slider-nav .thumbnail-image {
  position: relative;
  margin: 0 5px;
  cursor: pointer;
}

.popup-slider-nav .thumbnail-image,
.popup-slider-nav .thumbnail-image img {
  display: block;
  width: 140px;
  height: 100px;
}

.popup-slider-nav .thumbnail-image:after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  background-color: rgba(0, 0, 0, 0.6);
  -webkit-transition: all 0.2s linear;
  -moz-transition: all 0.2s linear;
  transition: all 0.2s linear;
}

.popup-slider-nav .thumbnail-image:hover:after {
  background-color: rgba(0, 0, 0, 0.4);
}

.popup-slider-nav .slick-current:after,
.popup-slider-nav .slick-current:hover:after,
.popup-slider-nav .slick-center:after,
.popup-slider-nav .slick-center:hover:after {
  background-color: transparent;
}

.pagingInfo {
  color: #fff;
  text-align: center;
  margin: 20px 0;
}

.popup-slider-for .slick-next,
.popup-slider-for .slick-prev {
  width: auto;
  height: auto;
  z-index: 1;
}

.popup-slider-for .slick-prev {
  left: 0;
}

.popup-slider-for .slick-prev:before,
.popup-slider-for .slick-next:before,
.popup-slider-for:after {
  font: normal normal 30px/1 'Glyphicons Halflings';
}

.popup-slider-for .slick-prev:before {
  content: "";
}

.popup-slider-for .slick-next:before {
  content: "";
}

.popup-slider-for .slick-next {
  right: 0;
}

.popup-image-gallery .close-icon {
  top: 0;
}

.slick-slide {
  outline: 0;
}

.close-btn {
  background-color: transparent;
  color: #fff;
  position: absolute;
  right: 30px;
  z-index: 3;
  font-size: 24px;
  margin: 0;
  opacity: .75;
}

.close-btn:hover,
.close-btn:focus {
  color: #fff;
  opacity: 10;
}

.popup-image-gallery .modal-dialog {
  margin: 0;
}

@media (max-width: 767px) {
  .popup-image-gallery .modal-body {
    padding: 0;
  }
  .popup-image-gallery .modal-dialog {
    margin-top: 20px;
  }
  .popup-image-gallery .close-icon {
    top: -20px;
  }
  .popup-slider-for .slick-prev {
    left: 12px;
  }
  .popup-slider-for .slick-next {
    right: 12px;
  }
}

/* my slider class */
.popup-image-gallery .modal-dialog {

    margin: auto;
}
.slick-next:before, .slick-prev:before {
    font-family: slick;
    font-size: 20px;
    line-height: 1;
    opacity: -0.25;
    color: #fff;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.fa.fa-angle-right,.fa-angle-left {
    color: white;
    /* border: 1px solid yellow; */
    font-size: 43px;
    padding: 17px;
    
}
h2.gly {
    text-align: center;
    font-size: 2.2rem;
    /* margin: 3rem 0 2rem; */
    text-transform: uppercase;
    letter-spacing: -0.02em;
    color: #fbebeb;
}
.popup-image-gallery .modal-content {
    -webkit-box-shadow: none;
    box-shadow: none;
    background-color: transparent;
    border: 0;
    border-radius: 0;
    margin-top: 34px;
}
img.img-dd {
    grid-row: 1 / span 3;
    grid-column: 1 / span 1;
    width: 577px;
    height: 421px;
    border:10px solid #DADCDB;
}
.close-btn {
    background-color: transparent;
    color: #fff;
    position: absolute;
    /* background: #ffdfdf; */
    right: 17px;
    z-index: 3;
    font-size: 24px;
    margin: 0;
    opacity: .75;
}



	a.polaroid:hover,
	a.polaroid:focus,
	a.polaroid:active {
		/* z-index: 999;
		border-color: #6A6A6A;
		-webkit-box-shadow: 2px 2px 4px rgba(0,0, 0, 0.3);
		-moz-box-shadow: 2px 2px 4px rgba(0,0, 0, 0.3);
		box-shadow: 2px 2px 4px rgba(0,0, 0, 0.3);
		-webkit-transform: rotate(0deg);
		-moz-transform: rotate(0deg);
		transform: rotate(0deg); */
	}
    .polaroid img {
    margin: 0 0 0px;
    width: 150px;
    height: 150px;
}
	
	a img {
		border: none;
		display: block;
	}
	
	.photo-album {
    position: relative;
   
    padding: 1em;
   
}
	.photo-album .polaroid {
		position: absolute;
	}
	.photo-album h1 {
		position: absolute;
		z-index: 5;
   
		top: 150px;
		text-align: center;
		width: 100%;
		line-height: 1.9;
	}
	.photo-album h1 span {
		background-color: white;
		font-family: "Helvetica Neue",Arial,Helvetica,sans-serif;
		padding: 0.4em 0.8em 0.3em 0.8em;
		-webkit-box-shadow: 2px 2px 4px rgba(0,0, 0, 0.3);
		-moz-box-shadow: 2px 2px 4px rgba(0,0, 0, 0.3);
		box-shadow: 2px 2px 4px rgba(0,0, 0, 0.3);
		border: 1px solid #6A6A6A;
  }


.main-div {
 
    padding-bottom: 40px;
}
svg.bi.bi-zoom-in {
    opacity: 0;
}
.photo-album:hover svg.bi.bi-zoom-in{
  opacity: 1;
}
	


.box {
        width: 200px;
        /* height: 200px; */
        position: absolute;
        bottom: 0;
        left: 0;
        /* opacity: 0.7; */
        background: white;
        display: block;
    padding: 0px 0px 3px 0px;
    font-size: 1em;
    border-radius: 8px;
    text-align: center;
    box-shadow: 2px 2px 4px rgb(0 0 0 / 30%);
    -webkit-transition: -webkit-transform 0.5s ease-in;
      }

      .overlay {

    margin: 15px;
    /* background: #009938; */
    position: absolute;
}
  .overlay1 {

    margin: 30px;
    /* background: #a10962; */
    position: relative;
}
.overlay img{
  width: 200px;
  height: 200px;
  border-top-left-radius: 8px;
    border-top-right-radius: 8px;
}
.overlay1 img{
  width: 200px;
  height: 200px;
  border-top-left-radius: 8px;
    border-top-right-radius: 8px;
}
.overlay2 img{
  width: 200px;
  height: 200px;
  border-top-left-radius: 8px;
    border-top-right-radius: 8px;
}


.r {


    /* position: absolute; */
    width: 100%;
    padding: 1rem;
    display: flex;
  flex-wrap: wrap;
  list-style: none;
  margin: 24px;
  margin-top:0px;
  padding: 0;
  margin-left: 27px;
    /* flex-direction: column; */
}
.f {
    position: relative;
  
    display: flex;
  width: 25%;
  padding: 0rem;
}

</style>






</head>
<body>

<div class="gallery-imag">
    <div class="gallery-bg">
  <h2 class="gly">Gallery</h2>
    </div>
</div>

  
<h1 class="gellery-text">Latest Photos</h1>    
<div class="container">


    <div class="main-div">
        <div class="r">
            <div class="f photo-album tm-video-item">
                <div class="box overlay1"><img src="images/img-03.jpg">   Ferntastic</div>
                <div class="box overlay"><img src="images/2.jpg">   Ferntastic</div>
              
                <div class="box  overlay2" data-toggle="modal" data-target="#popup-image-gallery" tabindex="0"><img src="images/img-13.jpg">
                <figcaption class="d-flex align-items-center justify-content-center">
             <h2><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-zoom-in" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
            <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z"/>
            <path fill-rule="evenodd" d="M6.5 3a.5.5 0 0 1 .5.5V6h2.5a.5.5 0 0 1 0 1H7v2.5a.5.5 0 0 1-1 0V7H3.5a.5.5 0 0 1 0-1H6V3.5a.5.5 0 0 1 .5-.5z"/>
            </svg></h2>
            </figcaption>
            Ferntastic
              </div>
                
              
            </div>
            <div class=" f photo-album tm-video-item">
              <div class="box overlay1"><img src="images/1.jpg">   Ferntastic</div>
              <div class="box overlay"><img src="images/img-04.jpg">   Ferntastic</div>
            
              <div class="box  overlay2" data-toggle="modal" data-target="#popup-image-gallery1" tabindex="0"><img src="images/img-03.jpg">
              <figcaption class="d-flex align-items-center justify-content-center">
            <h2><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-zoom-in" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
            <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z"/>
            <path fill-rule="evenodd" d="M6.5 3a.5.5 0 0 1 .5.5V6h2.5a.5.5 0 0 1 0 1H7v2.5a.5.5 0 0 1-1 0V7H3.5a.5.5 0 0 1 0-1H6V3.5a.5.5 0 0 1 .5-.5z"/>
            </svg></h2>
            </figcaption>
            Ferntastic
          </div>
            
            </div>
            <div class="f  photo-album tm-video-item">
              <div class="box overlay1"><img src="images/img-01.jpg">   Ferntastic</div>
              <div class="box overlay"><img src="images/img-15.jpg">   Ferntastic</div>
            
              <div class="box  overlay2" data-toggle="modal" data-target="#popup-image-gallery2" tabindex="0"><img src="images/img-06.jpg">
              <figcaption class="d-flex align-items-center justify-content-center">
            <h2><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-zoom-in" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
            <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z"/>
            <path fill-rule="evenodd" d="M6.5 3a.5.5 0 0 1 .5.5V6h2.5a.5.5 0 0 1 0 1H7v2.5a.5.5 0 0 1-1 0V7H3.5a.5.5 0 0 1 0-1H6V3.5a.5.5 0 0 1 .5-.5z"/>
            </svg></h2>
            </figcaption>
            Ferntastic
            </div>
            
            </div>
            <div class=" f photo-album tm-video-item">
              <div class="box overlay1"><img src="images/img-01.jpg">   Ferntastic</div>
              <div class="box overlay"><img src="images/15.jpg">   Ferntastic</div>
            
              <div class="box  overlay2" data-toggle="modal" data-target="#popup-image-gallery3" tabindex="0"><img src="images/img-04.jpg">
              <figcaption class="d-flex align-items-center justify-content-center">
            <h2><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-zoom-in" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
            <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z"/>
            <path fill-rule="evenodd" d="M6.5 3a.5.5 0 0 1 .5.5V6h2.5a.5.5 0 0 1 0 1H7v2.5a.5.5 0 0 1-1 0V7H3.5a.5.5 0 0 1 0-1H6V3.5a.5.5 0 0 1 .5-.5z"/>
            </svg></h2>
            </figcaption>
            Ferntastic
          </div>
            
            </div>
          
        </div>
        

    </div>
    </div>

 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 
<script>
 

$(".wrapp").hover(function(){
    $('.figcaption2').hide();
},function(){
    $('.figcaption2').show();
});
$(".wrapp1").hover(function(){
    $('.figcaption3').hide();
},function(){
    $('.figcaption3').show();
});
$(".wrapp2").hover(function(){
    $('.figcaption4').hide();
},function(){
    $('.figcaption4').show();
});
  </script>
     <div class="modal popup-image-gallery" id="popup-image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <button type="button" class="btn close-btn" title="Close" data-dismiss="modal" aria-label="Close">&#10006;</span></button>
              <div class="popup-slider-for">
                <div class="main-image">
                <img src="images/img-16.jpg" class="img-dd">
                </div>
                <div class="main-image">
                <img src="images/img-13.jpg" class="img-dd">
                </div>
                <div class="main-image">
                <img src="images/img-15.jpg" class="img-dd">
                </div>
                <div class="main-image">
                <img src="images/img-10.jpg" class="img-dd">
                </div>
                <div class="main-image">
                <img src="images/img-11.jpg" class="img-dd">
                </div>
              </div>
              <h6 class="pagingInfo"></h6>
     
            </div>
          </div>
        </div>
    </div>

    <div class="modal popup-image-gallery" id="popup-image-gallery1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <button type="button" class="btn close-btn" title="Close" data-dismiss="modal" aria-label="Close">&#10006;</span></button>
              <div class="popup-slider-for">
                <div class="main-image">
                  <img src="https://unsplash.it/340/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/360/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/380/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/400/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/420/?random" alt=""  class="img-dd">
                </div>
              </div>
              <h5 class="pagingInfo"></h5>
              <div class="popup-slider-nav hidden-xs">
           
              </div>
            </div>
          </div>
        </div>
    </div>
    <div class="modal popup-image-gallery" id="popup-image-gallery2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <button type="button" class="btn close-btn" title="Close" data-dismiss="modal" aria-label="Close">&#10006;</span></button>
              <div class="popup-slider-for">
                <div class="main-image">
                  <img src="https://unsplash.it/340/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/360/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/380/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/400/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/420/?random" alt=""  class="img-dd">
                </div>
              </div>
              <h5 class="pagingInfo"></h5>
              <div class="popup-slider-nav hidden-xs">
             
              </div>
            </div>
          </div>
        </div>
    </div>
    <div class="modal popup-image-gallery" id="popup-image-gallery3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <button type="button" class="btn close-btn" title="Close" data-dismiss="modal" aria-label="Close">&#10006;</span></button>
              <div class="popup-slider-for">
                <div class="main-image">
                  <img src="https://unsplash.it/340/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/360/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/380/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/400/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/420/?random" alt=""  class="img-dd">
                </div>
              </div>
              <h5 class="pagingInfo"></h5>
              <div class="popup-slider-nav hidden-xs">
             
              </div>
            </div>
          </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.js" integrity="sha512-WNZwVebQjhSxEzwbettGuQgWxbpYdoLf7mH+25A7sfQbbxKeS5SQ9QBf97zOY4nOlwtksgDA/czSTmfj4DUEiQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    
    <!-- slider-1 -->
     <script>
  $('#popup-image-gallery').on('shown.bs.modal', function() {
  $('.popup-slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,

    autoplay:true,
            arrows: true,
            prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
            nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    fade: true,
    asNavFor: '.popup-slider-nav',
    // adaptiveHeight: true,
  });
  $('.popup-slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.popup-slider-for',
    dots: false,
    arrows: false,
    focusOnSelect: true,
    variableWidth: true,
    centerMode: true,
    infinite: true,
  });
});
// Slick.js: Get current and total slides (ie. 3/5)
var $status = $('.pagingInfo');
var $slickElement = $('.popup-slider-for');

$slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide) {
  //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
  var i = (currentSlide ? currentSlide : 0) + 1;
  $status.text(i + '/' + slick.slideCount);
});




// slider-2
$('#popup-image-gallery1').on('shown.bs.modal', function() {
  $('.popup-slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,

    autoplay:true,
            arrows: true,
            prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
            nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    fade: true,
    asNavFor: '.popup-slider-nav',
    // adaptiveHeight: true,
  });
  $('.popup-slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.popup-slider-for',
    dots: false,
    arrows: false,
    focusOnSelect: true,
    variableWidth: true,
    centerMode: true,
    infinite: true,
  });
});
// Slick.js: Get current and total slides (ie. 3/5)
var $status = $('.pagingInfo');
var $slickElement = $('.popup-slider-for');

$slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide) {
  //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
  var i = (currentSlide ? currentSlide : 0) + 1;
  $status.text(i + '/' + slick.slideCount);
});

// Slick slider sync situation
// var slides = $(".popup-slider-for .slick-track > .slick-slide").length;
// $('.popup-slider-for').on('afterChange', function(event, slick, currentSlide, nextSlide) {
//   var inFocus = $('.popup-slider-for .slick-current').attr('data-slick-index');
//   $('.popup-slider-nav .slick-current').removeClass('slick-current');
//   $('.popup-slider-nav .slick-slide[data-slick-index="' + inFocus + '"]').trigger('click');
// });



// slider-3
$('#popup-image-gallery2').on('shown.bs.modal', function() {
  $('.popup-slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,

    autoplay:true,
            arrows: true,
            prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
            nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    fade: true,
    asNavFor: '.popup-slider-nav',
    // adaptiveHeight: true,
  });
  $('.popup-slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.popup-slider-for',
    dots: false,
    arrows: false,
    focusOnSelect: true,
    variableWidth: true,
    centerMode: true,
    infinite: true,
  });
});
// Slick.js: Get current and total slides (ie. 3/5)
var $status = $('.pagingInfo');
var $slickElement = $('.popup-slider-for');

$slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide) {
  //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
  var i = (currentSlide ? currentSlide : 0) + 1;
  $status.text(i + '/' + slick.slideCount);
});

// Slick slider sync situation
// var slides = $(".popup-slider-for .slick-track > .slick-slide").length;
// $('.popup-slider-for').on('afterChange', function(event, slick, currentSlide, nextSlide) {
//   var inFocus = $('.popup-slider-for .slick-current').attr('data-slick-index');
//   $('.popup-slider-nav .slick-current').removeClass('slick-current');
//   $('.popup-slider-nav .slick-slide[data-slick-index="' + inFocus + '"]').trigger('click');
// });
   </script>
<?php 
include_once('footer.php');
?>
