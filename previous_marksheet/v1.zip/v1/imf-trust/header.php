<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="style.css">
  
    <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;1,400&family=Roboto:wght@300;500&display=swap" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>
        <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->



    <!-- Latest compiled JavaScript -->
    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
</head>
<style>
    *{
    box-sizing: border-box;
}

body{
    font-family: 'Roboto', sans-serif;
    margin: 0;
    background-color:#fff;
    overflow-x: hidden;
}

/* Estilos del NavBar */
.tophead {
    background-color: white;
    overflow: hidden;
    background: #fbfbfb;
    border-bottom: 1px solid #eee;
  display:flex;
  justify-content:space-around;
  padding: 0;
}
/* a.social-media {
    color: grey;
    font-size: 15px;
    border-left: 1px solid #eee;
    padding: 15px;
} */
a.menu-item-1:hover{
    color:#fff;
    background-color:#3B5998;
  
}
a.menu-item-2:hover{
    color:#fff;
    background-color:#4285F4;
  
}
a.menu-item-3:hover{
    color:#fff;
    background-color:#0e76a8;
  
}
a.menu-item-4:hover{
    color:#fff;
    background-color:#4ddbff;
  
}
a.menu-item-5:hover{
    color:#fff;
    background-color: #80d4ff;
  
}
a.menu-item-6:hover{
    color:#fff;
    background-color:#FF0000;
  
}
.site-header {
    padding: 16px 0;
    background-color: #fff;
    transition: padding 0.2s ease-in-out 0s;
    clear: both;
    z-index: 999;
    position: relative;
   text-decoration: inherit;
}
/* .nav-link a {
    color: #568c11;
    text-decoration: inherit;

} */
.nav-link{
    color: #222;
    font-size: 18px;
    font-family: "Montserrat", sans-serif;
    padding-right: 1.5rem;
}
.site-title {
    color: #568c11;
    font-family: 'Montserrat', sans-serif;
    font-size: 28px;
    margin: 3px;
}
.navbar-expand-sm .navbar-nav .nav-link {
    padding-left: 0.5rem!important;
    padding-right: 1.5rem!important;
    font-family: 'Montserrat', sans-serif!important;
    font-size: 15px;
}
img.img-logo {
    width: 100%;
}
a.custom-button.doante-now {
    float: right;
    margin: -18px 0 0 20px;
    padding: 8px 17px;
    text-align: center;
    min-width: inherit;
    text-transform: capitalize;
    background-color: #568c11;
    text-transform: capitalize;
    color: #fff;
    text-decoration: none;
    font-family: "Montserrat", sans-serif;
}
.header-social-wrapper ul li a{
    border-right: 1px solid #eee;
    color: grey;
    font-size: 15px;
    border-left: 1px solid #eee;
    padding: 14px;
    text-decoration: none;
}
.header-social-wrapper1 ul li a{
    border-right: 1px solid #eee;
    color: #568c11;;
    font-size: 15px;
    border-left: 1px solid #eee;
    padding: 14px;
    text-decoration: none;
}
/* .header-social-wrapper1 {
    display: flex;
    justify-content: end;
} */
i#faa {
    padding: 2px;
}
/* .sticky.is-sticky {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    z-index: 1000;
    width: 100%;
} */

/* nav {
  background: #eaebec;
  min-height: 85px;
} */
/* #navbarCollapse {
    justify-content: center;
    color: #222;
    justify-content: space-around;
    font-size: 15px;
    font-weight: normal;
    padding: 15px 15px;
    position: relative;
    z-index: 99;
    font-weight: 500;
    font-family: "Montserrat", sans-serif!important;
    font-weight: 500;
} */
/* #navbarCollapse ul li a:hover{
color:#568c11;

} */
.carousel-indicators li {
    box-sizing: content-box;
    -ms-flex: 0 1 auto;
    flex: 0 1 auto;
    width: 30px;
    height: 7px;
    margin-right: 3px;
    margin-left: 3px;
    text-indent: -999px;
    cursor: pointer;
    background-color: #fff;
    background-clip: padding-box;
    border-top: 10px solid transparent;
    border-bottom: 10px solid transparent;
    opacity: .5;
    transition: opacity .6s ease;
}
#main-slider .cycle-prev:hover, #main-slider .cycle-next:hover {
    background-color: #9cc900;
    color: #fff;
    border-color: #9cc900;
}
.site-header {
    padding: 8px 0;
    background-color: #fff;
    transition: padding 0.2s ease-in-out 0s;
    clear: both;
    z-index: 999;
    position: relative;
   text-decoration: inherit;
}
/* .nav-link a {
    color: #568c11;
    text-decoration: inherit;

} */
.nav-link{
    color: #222;
    font-size: 18px;
    font-family: "Montserrat", sans-serif;
    padding-right: 1.5rem;
}
.site-title {
    color: #568c11;
    font-family: 'Montserrat', sans-serif;
    font-size: 28px;
    margin: 3px;
}
.navbar-expand-sm .navbar-nav .nav-link {
    padding-left: 0.5rem!important;
    padding-right: 1.5rem!important;
    font-family: 'Montserrat', sans-serif!important;
    font-size: 15px;
}
img.img-logo {
    width: 100%;
}
.site-header {
    padding: 16px 0;
    background-color: #fff;
    transition: padding 0.2s ease-in-out 0s;
    clear: both;
    z-index: 999;
    position: relative;
   text-decoration: inherit;
}
/* .nav-link a {
    color: #568c11;
    text-decoration: inherit;

} */
.nav-link{
    color: #222;
    font-size: 18px;
    font-family: "Montserrat", sans-serif;
    padding-right: 1.5rem;
}
.site-title {
    color: #568c11;
    font-family: 'Montserrat', sans-serif;
    font-size: 28px;
    margin: 3px;
}
.navbar-expand-sm .navbar-nav .nav-link {
    padding-left: 0.5rem!important;
    padding-right: 1.5rem!important;
    font-family: 'Montserrat', sans-serif!important;
    font-size: 15px;
}
img.img-logo {
    width: 100%;
}
a.custom-button.doante-now {
    float: right;
    margin: -18px 0 0 20px;
    padding: 8px 17px;
    text-align: center;
    min-width: inherit;
    text-transform: capitalize;
    background-color: #568c11;
    text-transform: capitalize;
    color: #fff;
    text-decoration: none;
    font-family: "Montserrat", sans-serif;
}
.navbar-toggler-icon {
  border-color: rgb(255,102,203);
} 
.navbar-toggler-icon{
background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(255,102,203, 0.5)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E");
}
.img_d{
    width: 30px;
    height: 30px;
    margin-right: 10px;
}
a.custom-button.doante-now {
    display: flex;
}
.donate_text {
    margin-bottom: 0px;
    padding-top: 4px;
}
img.log_g {
    width: 196px;
}

nav ul li a,
nav ul li a:after,
nav ul li a:before {
  transition: all .5s;
}
nav ul li a:hover {
  color: #555;
}


/* stroke */
#navbarCollapse ul li a,
{
  position: relative;
}
#navbarCollapse ul li a:after,
{
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  width: 0%;
  content: '.';
  color: transparent;
  background: #aaa;
  height: 1px;
}
#navbarCollapse ul li a:hover:after {
  width: 100%;
}
  </style>
<body>


<div class="navbar navbar-expand-sm sticky-top  tophead">
  <!-- Brand/logo -->
  <div class="header-social-wrapper">
  <ul class="navbar-nav" id="menu-item">
    <li class="nav-item">
      <a href="#" class="social-media menu-item-1"><i class="fa fa-facebook-f"></i></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-2"><i class="fa fa-twitter"></i></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-3"><i class="fa fa-linkedin"></i></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-4"><i class="fa fa-wordpress"></i></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-5"><i class="fa fa fa-instagram"></i></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-6"><i class="fa fa-youtube"></i></a>
    </li>
  </ul>
</div>
 
<div class="header-social-wrapper1">
<ul class="navbar-nav" id="menu-itemss">
    <li class="nav-item">
      <a href="#" class="social-media1"><i class="fa fa-phone" id="faa"></i><span>+977-9846120045</span></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media1"><i class="fa fa-envelope" id="faa"></i> <span> demooo@example.com </span></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media1"><i class="fa fa-globe" id="faa"></i><span>Kathmandu, Nepal</span></a>
    </li>
 
  </ul>
</div>
</div>

<!--top header-->
<header class="sticky-top">
            <!--most top info -->
         
            <!-- End most top info -->
            <nav class="navbar navbar-white navbar-expand-sm  site-header ">
        <div class="container">
        <a href="#" class="navbar-brand"><p class="site-title"> <img src="images/Group 308.png" class="log_g"></p></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
     <div id="navbarCollapse" class="collapse navbar-collapse navbar-right nav-menus">
        <ul class="navbar-nav ms-auto" id="menu-items" >
            <li class="nav-item navbar-right">
                <a href="" class="nav-link active">
                    Home
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="" class="nav-link active">
                   About Us
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="" class="nav-link active">
                Services
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="" class="nav-link active">
                    Volunteers
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="" class="nav-link active">
                    Blog
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="" class="nav-link active">
             News
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="" class="nav-link active">
                <a href="#" class="custom-button doante-now"><img src="images/solidarity.png" class="img_d"><p class="donate_text">Donate Now</p></a>
                </a>
            </li>
          
           
        </ul>
        </div>
      </div>
   </header>
        <!-- End top header-->
 

