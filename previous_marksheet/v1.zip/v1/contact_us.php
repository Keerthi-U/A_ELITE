<?php
include_once('header.php');
?>


<link rel="stylesheet" href="style.css"> 
<style>
.conn {
    display: flex;
    padding: 1.5rem;
    border-radius: 5px;
    transform: translateY(-59px);
    background: white;
    font-family: 'Titillium Web',sans-serif;
    color: black;
    clear: both;
    border: 0px;
    border-radius: 0px;
    /* border-bottom: 2px solid #c02424; */
    height: 238px;
    /* box-shadow: 0 2px 12px rgb(0 0 0 / 10%); */
    /* box-shadow: inset 0px -100px 170px -5px rgb(0 0 0 / 75%); */
    /* box-shadow: 0 0 29px 0 rgb(18 66 101 / 8%); */
    /* box-shadow: 3px 2px 15px rgb(18 66 101 / 78%); */
    box-shadow: 3px 2px 15px rgb(150 151 152 / 78%);
    transition: all 0.3s ease-in-out;
}
.con_contant1 {
    width: 58%;
    border: 0px;
    border-radius: 0px;
    border-right: 2px solid #c02424;
    padding: 1.1rem;
}
.con_contant2 {
   
    padding-left: 49px;
    padding: 1.1rem;
    padding-left: 37px;
    padding-top: 7px;
}
.required:after{
content:"*";
color:red;
}
.fa{
  
}
.fa-map-marker{
    color: #D13238!important;
    font-size: 23.3px!important;
    margin-top: 5px;
}
#ico{
    color: #D13238!important; 
}
select#ddCountry {
    /* margin-bottom: 0px; */
    margin-top: -21px;
}
</style>

<!-- first section  -->

<div class="conatiner-fuild">
    <div class="bg_img_sec">
        <div class="b_g ">
     

        </div>
    </div>
    <div class="sticky-social">
  <!-- <ul class="social">
    <li class="fb"><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li class="twitter"><a href="#"><i class="fa fa-twitter" id="sidesocial" aria-hidden="true"></i></a></li>
      <li class="insta"><a href="#"><i class="fa fa-instagram"  id="sidesocial" aria-hidden="true"></i></a></li>
      <li class="pin"><a href="#"><i class="fa fa-pinterest-p"  id="sidesocial" aria-hidden="true"></i></a></li>
      <li class="vim"><a href="#"><i class="fa fa-vimeo"  id="sidesocial" aria-hidden="true"></i></a></li>
    </ul> -->
  </div>
</div>
<div class="content-section  pt-0">
   <div class="container">
      <div class="row" ID="FF">
         <div class="col-md-10 offset-md-1">
                <div class="conn">
                <div class="con_contant1">
                 <h1 class="text-blackk">Contact us</h1>
                  <p> You can get in touch at the addresses and telephone numbers mentioned or fill in the form to contact us.
                 </p>
             </div>
             <div class="con_contant2">
             <div class="bg-whit">
                     <h5 class="text-uppercase font-weight-bold mb-1"> Register office</h5>
                     <p class="mb-2"><i class="fa fa-map-marker" id="ico"  aria-hidden="true"></i><span>&nbsp;#257, Bazaar street,<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (opp.Charminar st.) Pernambut</span>


</p>
                     <p class="mb-2 w-icon w-icon-black"> <i class="fa fa-phone" id="ico"  aria-hidden="true"></i>+91 9677463675 </p>
                     <p class="mb-2 w-icon w-icon-black i-fax"><i class="fa fa-whatsapp" id="ico" ></i>+91 7200863675 </p>
                     <p class="mb-2 w-icon w-icon-black i-mail"><a href="mailto:imantrust21@gmail.com"><i class="fa fa-envelope" id="ico" ></i>imantrust21@gmail.com</a></p>
                 </div>
                 </div>
                </div>
       

         </div>
              <!-- <div class=" offset-lg-1 col-md-6  align-items-center">
                  <div class="con_contant">
                  <h1 class="text-blackk">Contact us</h1>
                  <p> You can get in touch at the addresses and telephone numbers mentioned or fill in the form to contact us.
                 </p>
                  </div>
        
             </div>
        
             <div class="col-md-4 offset-md-1-right">
             <div class="bg-white ">
                     <h5 class="text-uppercase font-weight-bold mb-1">Support office</h5>
                     <p class="mb-2">World Trade Center-1, 26th floor<br> Cuffe Parade, Mumbai 400 005, India</p>
                     <p class="mb-2 w-icon w-icon-black"> <i class="fa fa-phone" id="ico"  aria-hidden="true"></i>+91 - 22 - 6665 8282 </p>
                     <p class="mb-2 w-icon w-icon-black i-fax"><i class="fa fa-tty" id="ico" ></i>+91 - 22 - 6135 8369</p>
                     <p class="mb-2 w-icon w-icon-black i-mail"><a href="mailto:talktous@tatatrusts.org"><i class="fa fa-envelope" id="ico" ></i>talktous@tatatrusts.org</a></p>
                 </div>
            </div>
         </div> --> 
  
     </div> 
 </div>


            <div class="write-to-us-form common-padding">
                <div class="container">
            
                    <div class="row">
                       <div class="col-md-8 col-sm-12 offset-md-2 offset-sm-0">
                       <h5 class="after-none mb-4 mt-4">Write to us</h5>
                       	

                         <div class="form-group row">
                             <label class="col-md-4 col-sm-12 col-form-label required"  for="name">Full Name</label>
                                 <div class="col-md-8 col-sm-12">
                                     <input Id="nametxt" class="form-control"  id="name" name="name" type="text" value="" />
                                 </div>
                         </div>
                         <div class="form-group row">
                             <label class="col-md-4 col-sm-12 col-form-label  required" for="name">Email</label>
                                 <div class="col-md-8 col-sm-12">
                                     <input Id="nametxt" class="form-control"  id="name" name="name" type="text" value="" />
                                 </div>
                         </div>
                         <div class="form-group row">
                             <label class="col-md-4 col-sm-12 col-form-label" for="name">Phone Number</label>
                                 <div class="col-md-8 col-sm-12">
                                     <input Id="nametxt" class="form-control"  id="name" name="name" type="text" value="" />
                                 </div>
                         </div>
                      <div class="form-group row">
                          <label class="col-md-4 col-sm-12 col-form-label " for="name">Country</label>
                            <div class="col-md-8 col-sm-12">
                                            <div class="select">
                                                
                                            <i class="fa fa-angle-down"></i>
                                            <select class="select form-control" data-val="true" data-val-number="The field Country* must be a number." data-val-required="Please select Country" id="ddCountry" name="Country_ID"><option value="">Select Country</option>
                                                <option value="1">Afghanistan</option>
                                                <option value="2">Albania</option>
                                                <option value="3">Algeria</option>
                                                <option value="4">American Samoa</option>
                                                <option value="5">Andorra</option>
                                                <option value="6">Angola</option>
                                                <option value="7">Anguilla</option>
                                                <option value="8">Antarctica</option>
                                                <option value="9">Antigua and Barbuda</option>
                                                <option value="10">Argentina</option>
                                                <option value="11">Armenia</option>
                                                <option value="12">Aruba</option>
                                                <option value="13">Australia</option>
                                                <option value="14">Austria</option>
                                                <option value="15">Azerbaijan</option>
                                                <option value="16">Bahamas</option>
                                                <option value="17">Bahrain</option>
                                                <option value="18">Bangladesh</option>
                                                <option value="19">Barbados</option>
                                                <option value="20">Belarus</option>
                                                <option value="21">Belgium</option>
                                                <option value="22">Belize</option>
                                                <option value="23">Benin</option>
                                                <option value="24">Bermuda</option>
                                                <option value="25">Bhutan</option>
                                                <option value="26">Bolivia</option>
                                                <option value="27">Bosnia and Herzegovina</option>
                                                <option value="28">Botswana</option>
                                                <option value="29">Bouvet Island</option>
                                                <option value="30">British Indian Ocean Territory</option>
                                                <option value="31">Brunei</option>
                                                <option value="32">Bulgaria</option>
                                                <option value="33">Burkina Faso</option>
                                                <option value="34">Burundi</option>
                                                <option value="35">Cambodia</option>
                                                <option value="36">Cameroon</option>
                                                <option value="37">Canada</option>
                                                <option value="38">Cape Verde</option>
                                                <option value="39">Cayman Islands</option>
                                                <option value="40">Central African Republic</option>
                                                <option value="41">Chad</option>
                                                <option value="42">Chile</option>
                                                <option value="43">China</option>
                                                <option value="44">Christmas Island</option>
                                                <option value="45">Cocos (Keeling) Islands</option>
                                                <option value="46">Colombia</option>
                                                <option value="47">Comoros</option>
                                                <option value="48">Congo</option>
                                                <option value="49">Cook Islands</option>
                                                <option value="50">Costa Rica</option>
                                                <option value="53">Cuba</option>
                                                <option value="54">Cyprus</option>
                                                <option value="55">Czech Republic</option>
                                                <option value="57">Denmark</option>
                                                <option value="58">Djibouti</option>
                                                <option value="59">Dominica</option>
                                                <option value="60">Dominican Republic</option>
                                                <option value="61">East Timor</option>
                                                <option value="62">Ecuador</option>
                                                <option value="63">Egypt</option>
                                                <option value="64">El Salvador</option>
                                                <option value="65">Equatorial Guinea</option>
                                                <option value="66">Eritrea</option>
                                                <option value="67">Estonia</option>
                                                <option value="68">Ethiopia</option>
                                                <option value="70">Faroe Islands</option>
                                                <option value="71">Fiji Islands</option>
                                                <option value="72">Finland</option>
                                                <option value="73">France</option>
                                                <option value="74">French Guiana</option>
                                                <option value="75">French Polynesia</option>
                                                <option value="76">French Southern and Antarctic Lands</option>
                                                <option value="77">Gabon</option>
                                                <option value="78">Gambia</option>
                                                <option value="79">Georgia</option>
                                                <option value="80">Germany</option>
                                                <option value="81">Ghana</option>
                                                <option value="82">Gibraltar</option>
                                                <option value="83">Greece</option>
                                                <option value="84">Greenland</option>
                                                <option value="85">Grenada</option>
                                                <option value="86">Guadeloupe</option>
                                                <option value="87">Guam</option>
                                                <option value="88">Guatemala</option>
                                                <option value="89">Guinea</option>
                                                <option value="90">Guinea-Bissau</option>
                                                <option value="91">Guyana</option>
                                                <option value="92">Haiti</option>
                                                <option value="93">Heard Island and McDonald Islands</option>
                                                <option value="94">Honduras</option>
                                                <option value="95">Hong Kong SAR</option>
                                                <option value="96">Hungary</option>
                                                <option value="97">Iceland</option>
                                                <option value="98">India</option>
                                                <option value="99">Indonesia</option>
                                                <option value="100">Iran</option>
                                                <option value="101">Iraq</option>
                                                <option value="102">Ireland</option>
                                                <option value="103">Israel</option>
                                                <option value="104">Italy</option>
                                                <option value="105">Jamaica</option>
                                                <option value="106">Japan</option>
                                                <option value="107">Jordan</option>
                                                <option value="108">Kazakhstan</option>
                                                <option value="109">Kenya</option>
                                                <option value="110">Kiribati</option>
                                                <option value="111">Korea</option>
                                                <option value="112">Kuwait</option>
                                                <option value="113">Kyrgyzstan</option>
                                                <option value="114">Laos</option>
                                                <option value="115">Latvia</option>
                                                <option value="116">Lebanon</option>
                                                <option value="117">Lesotho</option>
                                                <option value="118">Liberia</option>
                                                <option value="119">Libya</option>
                                                <option value="120">Liechtenstein</option>
                                                <option value="121">Lithuania</option>
                                                <option value="122">Luxembourg</option>
                                                <option value="123">Macao SAR</option>
                                                <option value="124">Macedonia, Former Yugoslav Republic</option>
                                                <option value="125">Madagascar</option>
                                                <option value="126">Malawi</option>
                                                <option value="127">Malaysia</option>
                                                <option value="128">Maldives</option>
                                                <option value="129">Mali</option>
                                                <option value="130">Malta</option>
                                                <option value="131">Marshall Islands</option>
                                                <option value="132">Martinique</option>
                                                <option value="133">Mauritania</option>
                                                <option value="134">Mauritius</option>
                                                <option value="135">Mayotte</option>
                                                <option value="136">Mexico</option>
                                                <option value="137">Micronesia</option>
                                                <option value="138">Moldova</option>
                                                <option value="139">Monaco</option>
                                                <option value="140">Mongolia</option>
                                                <option value="141">Montserrat</option>
                                                <option value="142">Morocco</option>
                                                <option value="143">Mozambique</option>
                                                <option value="144">Myanmar</option>
                                                <option value="145">Namibia</option>
                                                <option value="146">Nauru</option>
                                                <option value="147">Nepal</option>
                                                <option value="148">Netherlands</option>
                                                <option value="149">Netherlands Antilles</option>
                                                <option value="150">New Caledonia</option>
                                                <option value="151">New Zealand</option>
                                                <option value="152">Nicaragua</option>
                                                <option value="153">Niger</option>
                                                <option value="154">Nigeria</option>
                                                <option value="155">Niue</option>
                                                <option value="156">Norfolk Island</option>
                                                <option value="157">North Korea</option>
                                                <option value="158">Northern Mariana Islands</option>
                                                <option value="159">Norway</option>
                                                <option value="160">Oman</option>
                                                <option value="161">Pakistan</option>
                                                <option value="162">Palau</option>
                                                <option value="163">Panama</option>
                                                <option value="164">Papua New Guinea</option>
                                                <option value="165">Paraguay</option>
                                                <option value="166">Peru</option>
                                                <option value="167">Philippines</option>
                                                <option value="168">Pitcairn Islands</option>
                                                <option value="169">Poland</option>
                                                <option value="170">Portugal</option>
                                                <option value="171">Puerto Rico</option>
                                                <option value="172">Qatar</option>
                                                <option value="173">Reunion</option>
                                                <option value="174">Romania</option>
                                                <option value="175">Russia</option>
                                                <option value="176">Rwanda</option>
                                                <option value="177">Samoa</option>
                                                <option value="178">San Marino</option>
                                                <option value="180">Saudi Arabia</option>
                                                <option value="181">Senegal</option>
                                                <option value="182">Serbia and Montenegro</option>
                                                <option value="183">Seychelles</option>
                                                <option value="184">Sierra Leone</option>
                                                <option value="185">Singapore</option>
                                                <option value="186">Slovakia</option>
                                                <option value="187">Slovenia</option>
                                                <option value="188">Solomon Islands</option>
                                                <option value="189">Somalia</option>
                                                <option value="190">South Africa</option>
                                                <option value="192">Spain</option>
                                                <option value="193">Sri Lanka</option>
                                                <option value="194">St. Helena</option>
                                                <option value="195">St. Kitts and Nevis</option>
                                                <option value="196">St. Lucia</option>
                                                <option value="197">St. Pierre and Miquelon</option>
                                                <option value="198">St. Vincent and the Grenadines</option>
                                                <option value="199">Sudan</option>
                                                <option value="200">Suriname</option>
                                                <option value="201">Svalbard and Jan Mayen</option>
                                                <option value="202">Swaziland</option>
                                                <option value="203">Sweden</option>
                                                <option value="204">Switzerland</option>
                                                <option value="205">Syria</option>
                                                <option value="206">Taiwan</option>
                                                <option value="207">Tajikistan</option>
                                                <option value="208">Tanzania</option>
                                                <option value="209">Thailand</option>
                                                <option value="210">Togo</option>
                                                <option value="211">Tokelau</option>
                                                <option value="212">Tonga</option>
                                                <option value="213">Trinidad and Tobago</option>
                                                <option value="214">Tunisia</option>
                                                <option value="215">Turkey</option>
                                                <option value="216">Turkmenistan</option>
                                                <option value="217">Turks and Caicos Islands</option>
                                                <option value="218">Tuvalu</option>
                                                <option value="219">Uganda</option>
                                                <option value="220">Ukraine</option>
                                                <option value="221">United Arab Emirates</option>
                                                <option value="222">United Kingdom</option>
                                                <option value="223">United States</option>
                                                <option value="224">United States Minor Outlying Islands</option>
                                                <option value="225">Uruguay</option>
                                                <option value="226">Uzbekistan</option>
                                                <option value="227">Vanuatu</option>
                                                <option value="228">Vatican City</option>
                                                <option value="229">Venezuela</option>
                                                <option value="230">Viet Nam</option>
                                                <option value="232">Virgin Islands</option>
                                                <option value="233">Wallis and Futuna</option>
                                                <option value="234">Yemen</option>
                                                <option value="235">Zambia</option>
                                                <option value="236">Zimbabwe</option>
                                                </select>

                                             <span class="field-validation-valid" data-valmsg-for="Country_ID" data-valmsg-replace="true"></span>
                                            </div>
                                        </div>
                               
                         </div>
                         <div class="form-group row">
                             <label class="col-md-4 col-sm-12 col-form-label" for="name">State</label>
                                 <div class="col-md-8 col-sm-12">
                                     <input Id="nametxt" class="form-control"  id="name" name="name" type="text" value="" />
                                 </div>
                         </div>
                         <div class="form-group row">
                             <label class="col-md-4 col-sm-12 col-form-label" for="name">City</label>
                                 <div class="col-md-8 col-sm-12">
                                     <input Id="nametxt" class="form-control"  id="name" name="name" type="text" value="" />
                                 </div>
                         </div>
                        
                         <div class="form-group row">
                              <label class="col-md-4 col-sm-12 col-form-label  required" for="name">  Message</label>
                              <div class="col-md-8 col-sm-12">
                              <textarea  class="form-control"></textarea >
                              </div>
                         </div>

                      

                         <div class="form-group row">
                            <label for="" class="col-md-12 col-sm-12 col-form-label" style="margin-top: 30px;">
                            <input  id="IsNewsletterAlert" name="IsNewsletterAlert" type="checkbox" value="True" /><input name="IsNewsletterAlert" type="hidden" value="false" />
                             I Agree to the terms and conditions 
                             </label>
                        </div>

                                        
                        <div class="form-group row">
                        <div class="col-md-8 col-sm-12 offset-md-4">
                            <input id="btnSave" name="Command" type="submit" value="Submit" class="submit-btn tata-trust-bg" />
                         </div>
                        </div>
                        </form>





                         </div>
                     </div>
                </div>
           </div>



           <?php include_once ('footer.php');?>