<?php
include("header.php");
?>
<style>
    .image-crop {
	display: block;
	position: relative;
	background-color: #E6EBEE;
	width: 110px;
	height: 110px;
	margin: 0 auto;
	margin-top: 30px;
	overflow: hidden;
	border-radius: 50%;
  transform: translateY(27px);

}
.image-crop:hover{
  box-shadow: 0 0 0 5px #f7f5ec;
  background-color: #ff9999;
}
.crop-image {
    /* background-image: url(images/3.jpg); */
    transform: translateY(-29px);
}

#avatar {
	display: inline;
    height: 160px;
    /* width: auto; */
    /* margin-left: -16px; */
    width: 110px;
}
.card-title {
    margin: 10px;
    font-size: 14px;
}
.card-content {
    text-align:center;
    font-family: Courier, Monaco, monospace;
    font-size: 17px;
    font-weight: 700;
    text-transform:uppercase;
}
.text-card {
    text-align: justify;
}
.card-center {
    text-align: center;
    font-family: 'Montserrat', sans-serif;
}
.card {
    /* margin: 7px; */
    margin-top: 20px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    
}
/* h6.text-center {
    font-size: 15px;
    font-weight: 300;
    margin-top: 5px;
    font-family: tahoma;
    color: #919191;
} */
.py-5 {
    /* background-color: aliceblue;
    background-color: #d7b5b5; */
    border-radius: 50px 50px 50px 50px;
    margin: 0px;
    /* box-shadow: 0 10px 15px rgb(110 221 235 / 53%); */
    /* box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px; */
    /* background-color: rgb(169 118 118 / 20%); */
    box-shadow: rgb(0 0 0 / 24%) 0px 3px 8px;
    background-color: rgb(223 218 218 / 20%);
}
.voluntees{
  text-align:center;
  text-transform: uppercase;
  color: #766c6c;
  font-family: 'Roboto';
  color: #706767;
  margin-top: -22px;
}
.imf-vol::after{
  clear: both;
    content: "";
    display: block;
    left: 0;
    border: 2px solid #c74b50;
    width: 130px;
    margin: 7px auto;
}   
.cardss:hover{
  /* animation:transition 7s ease infinite; */
          font-size:0px;
          transition: 0.1s;
          background-color:	 #ffe6e6;
          /* transform:scale(1.1);
          */
          transition: all 0.2s ease;
        }

@keyframes transition{
  0%{background-color:rgba(255,0,0,0.5);
     /* box-shadow:25px 25px 5px rgba(148,0,211,0.7); */
     transform:scale(1.2);}
  
  7.1%{background-color:rgba(255,0,0,0.5);
       /* box-shadow:25px 25px 5px rgba(148,0,211,0.3); */
        transform:scale(1.1);}
  
  14.3%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(75,0,130,0.7); */
        transform:scale(1.2);}
  
  21.4%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(75,0,130,0.3); */
        transform:scale(1.1);}
  
  28.6%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(0,0,255,0.7); */
        transform:scale(1.2);}
  
  35.7%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(0,0,255,0.3); */
        transform:scale(1.1);}
  
  42.9%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(0,255,0,0.7); */
        transform:scale(1.2);}
  
  50%{background-color:rgba(255,0,0,0.5);
      /* box-shadow:25px 25px 5px rgba(0,255,0,0.3); */
        transform:scale(1.1);}
  
  57.2%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(255,255,0,0.7); */
        transform:scale(1.2);}
  
  64.3%{background-color:rgba(255,0,0,0.5);
  /* box-shadow:25px 25px 5px rgba(255,255,0,0.3); */
        transform:scale(1.1);}
  
  71.5%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(255,127,0,0.7); */
        transform:scale(1.2);}
  
  78.6%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(255,127,0,0.3); */
       transform:scale(1.1);}
  
  85.8%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(255,0,0,0.7); */
       transform:scale(1.2);}
  
  92.9%{background-color:rgba(255,0,0,0.5);
        /* box-shadow:25px 25px 5px rgba(255,0,0,0.3); */
       transform:scale(1.1);}
  
  100%{background-color:rgba(255,0,0,0.5);
       /* box-shadow:25px 25px 5px rgba(148,0,211,0.7); */
       transform:scale(0.2);}
}
a.collapsed {
    text-decoration: none;
}
.voluter-laylout {
    padding-top: 10px;
    padding-bottom:27px;
}
i.fa.fa-angle-down {
    float: right;
}
.layout {
  padding-bottom: 0px;
    /* background: #f8f8f8; */
    padding-top: 50px;
}
a.volt {
    text-decoration: none;
}
.volunts {
    text-align: center;
    text-transform: uppercase;
    color: #766c6c;
    font-family: 'Roboto';
    color: #706767;
}
.volunts::after{
  clear: both;
    content: "";
    display: block;
    left: 0;
    border: 2px solid #c74b50;
    width: 130px;
    margin: 7px auto;

}
.support {
    padding-top: 50px;
}
.forum {
    border-top: 2px solid #c74b50;
    text-align: left;
    padding: 14px 0px 25px 13px;
    background-color: #fffdfd;
    /* border: 1px solid red; */
    margin: 10px;
    box-shadow: rgb(100 100 111 / 20%) 0px 7px 29px 0px;
}
.forum {
    border-top: 2px solid #c74b50;
    text-align: left;
    padding: 14px 0px 25px 13px;
    background-color: #fffdfd;
    /* border: 1px solid red; */
    margin: 10px;
    box-shadow: rgb(100 100 111 / 20%) 0px 7px 29px 0px;
    height: 200px;
}
.man{
  margin-bottom: 1.5rem;
    font-weight: 600;
    line-height: 1.2;
    font-size: 16px;
text-transform:uppercase;
}
.example {
    color: #857e7e;
    font-size: 15px;
}
/* .inform span{
  font-size: 0.8rem;
  color: #fff;
  text-transform: uppercase;
  text-align: center;
  font-weight: bold;
  line-height: 32px;
  transform: rotate(45deg);
  width: 125px;
  display: block;
  background: #79a70a;
  background: linear-gradient(#db3434 0%, #dd1818 100%);
  box-shadow: 0 3px 10px -5px rgba(0, 0, 0, 1);
  position: absolute;
  top: 17px; // change this, if no border
  right: -29px; // change this, if no border
}
.inform span::before {
   content: '';
   position: absolute; 
   left: 0px; top: 100%;
   z-index: -1;
   border-left: 3px solid #79A70A;
   border-right: 3px solid transparent;
   border-bottom: 3px solid transparent;
   border-top: 3px solid #79A70A;
}
.inform span::after {
   content: '';
   position: absolute; 
   right: 0%; top: 100%;
   z-index: -1;
   border-right: 3px solid #79A70A;
   border-left: 3px solid transparent;
   border-bottom: 3px solid transparent;
   border-top: 3px solid #79A70A;
} */
/* .col-md-3.ss {
    border-left: 1px solid red;
} */
.voluntee {
    padding-bottom: 50px;
    padding-top: 32px;
}
.interested {
    padding-bottom: 10px;
    background-color: #ebebeb;
    padding-left: 33px;

}
/* .inter {
    margin: 0 0 0 17px;
} */
.demo{
  padding-top: 13px;
}
.v-img {
   
    margin-right: 12px;
    padding-bottom: 4px;
}
   </style>


<section>
  <div class="voluter-laylout">
    <div class="layout">
      <div class="volunts">
        <h4 class="text-center">We invite volunteers for support </h4>
        <!-- <p class="text-center">invites Volunteers to support physically for the following cause </p> -->
      </div>
    <div class="container">
    <div class="support">
      <div class="row">
       
        <div class="col-md-3 ss">
         
          <div class="forum">
          <!-- <div class="inform">
            <span>Voluneers</span>
          </div> -->
          <h6 class="man">HR connects</h6>
          <div class="example">
            <p>All those who are interested to volunteer can register .themselves with I MAN Forum.themselves with I MAN Forum</p>
          </div>
          </div>
        </div>
        <div class="col-md-3 ss ">
        
          <div class="forum">
          <!-- <div class="inform">
            <span>Voluneers</span>
          </div> -->
                 <h6 class="man">Soft skills training</h6>
          
          <div class="example">
            <p>All those who are interested to volunteer can register themselves with I MAN Forum.themselves with I MAN Forum</p>
          </div>
          </div>
        </div>
        <div class="col-md-3 ss">
          <div class="forum">
          <!-- <div class="inform">
            <span>Voluneers</span>
          </div> -->
          <h6 class="man">Career Counselling</h6>
          <div class="example">
            <p>All those who are interested to volunteer can register themselves with I MAN Forum.themselves with I MAN Forum</p>
          </div>
          </div>
        </div>
        <div class="col-md-3 ss">
          <div class="forum">
          <!-- <div class="inform">
            <span>Voluneers</span>
          </div> -->
          <h6 class="man">Tailoring Training</h6>
          <div class="example">
            <p>All those who are interested to volunteer can register themselves with I MAN Forum.themselves with I MAN Forum</p>
          </div>
          </div>
        </div>
        <div class="col-md-3 ss">
          <div class="forum">
          <!-- <div class="inform">
            <span>Voluneers</span>
          </div> -->
          <h6 class="man">Plumbing Training</h6>
          <div class="example">
            <p>All those who are interested to volunteer can register themselves with I MAN Forum.themselves with I MAN Forum</p>
          </div>
          </div>
        </div>
        <div class="col-md-3 ss">
          <div class="forum">
          <!-- <div class="inform">
            <span>Voluneers</span>
          </div> -->
          <h6 class="man">Driver Training</h6>
          <div class="example">
            <p>All those who are interested to volunteer can register themselves with I MAN Forum.themselves with I MAN Forum</p>
          </div>
          </div>
        </div>
        <div class="col-md-3 ss">
          <div class="forum">
          <!-- <div class="inform">
            <span>Voluneers</span>
          </div> -->
          <h6 class="man">Mechanic Training</h6>
          <div class="example">
            <p>All those who are interested to volunteer can register themselves with I MAN Forum.themselves with I MAN Forum</p>
          </div>
          </div>
        </div>
        <div class="col-md-3 ss">
          <div class="forum">
          <!-- <div class="inform">
            <span>Voluneers</span>
          </div> -->
          <h6 class="man">Any other relief & charitable activities</h6>
          <div class="example">
            <p>All those who are interested to volunteer can register themselves with I MAN Forum.themselves with I MAN Forum</p>
          </div>
          </div>
        </div>
      </div>
    </div>
</div>
</div>

</section>

<section>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="interested">
         <h6 class="demo"><img src="images/star.png" class="v-img">All those who are interested to volunteer can register themselves with I MAN Forum</h6>
         <div class="inter">
            <h6 class="demo"><img src="images/star.png" class="v-img">May Almighty reward you both in this world and hereafter for the great initiative taken.</h6>
            </div>
          </div>

      </div>
    </div>
  </div>
</scetio>





<div class="voluntee">
<div class="py-5">
  <div class="voluntees">
  <h4 class="imf-vol">Volunteers</h4>
  </div>
 
    <div class="container">
      <div class="row hidden-md-up">
        <div class="col-lg-3 col-md-6">
          <div class="card cardss">
             <div class="card-block">
              <div class="crop-image">
                 <div class="image-crop">
		                    <img id="avatar" src="images/a.jpg"></img>
	               </div>
              </div>
                <div class="card-title">
                    <h6 class="card-content">Ramesh</h6>
                    <h6 class="text-center">PHP Developer</h6>
                    <p class="card-center">Some quick example text to build.Some quick example.<p>  
                </div>
             </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="card cardss">
             <div class="card-block">
              <div class="crop-image">
                 <div class="image-crop">
		                    <img id="avatar" src="images/b.jpg"></img>
	               </div>
              </div>
                <div class="card-title">
                    <h6 class="card-content">keerthi</h6>
                    <h6 class="text-center">UI/UX Developer</h6>
                    <p class="card-center">Some quick example text to build.Some quick example.<p>  
                </div>
             </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="card cardss">
             <div class="card-block">
              <div class="crop-image">
                 <div class="image-crop">
		                    <img id="avatar" src="images/20.jpg"></img>
	               </div>
              </div>
                <div class="card-title">
                    <h6 class="card-content">liya</h6>
                    <h6 class="text-center">Java Developer</h6>
                    <p class="card-center">Some quick example text to build.Some quick example.<p>  
                </div>
             </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="card cardss">
             <div class="card-block">
              <div class="crop-image">
                 <div class="image-crop">
		                    <img id="avatar" src="images/c.jpg"></img>
	               </div>
              </div>
                <div class="card-title">
                    <h6 class="card-content">Mugilan</h6>
                    <h6 class="text-center">Flutter</h6>
                    <p class="card-center">Some quick example text to build.Some quick example.<p>  
                </div>
             </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="card cardss">
             <div class="card-block">
              <div class="crop-image">
                 <div class="image-crop">
		                    <img id="avatar" src="images/d.jpg"></img>
	               </div>
              </div>
                <div class="card-title">
                    <h6 class="card-content">Mugilan</h6>
                    <h6 class="text-center">ReactJs</h6>
                    <p class="card-center">Some quick example text to build.Some quick example.<p>  
                </div>
             </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="card cardss">
             <div class="card-block">
              <div class="crop-image">
                 <div class="image-crop">
		                    <img id="avatar" src="images/e.jpg"></img>
	               </div>
              </div>
                <div class="card-title">
                    <h6 class="card-content">Mugilan</h6>
                    <h6 class="text-center">DotNet</h6>
                    <p class="card-center">Some quick example text to build.Some quick example.<p>  
                </div>
             </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="card cardss">
             <div class="card-block">
              <div class="crop-image">
                 <div class="image-crop">
		                    <img id="avatar" src="images/20.jpg"></img>
	               </div>
              </div>
                <div class="card-title">
                    <h6 class="card-content">Mugilan</h6>
                    <h6 class="text-center">React/Native</h6>
                    <p class="card-center">Some quick example text to build.Some quick example.<p>  
                </div>
             </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="card cardss">
             <div class="card-block">
              <div class="crop-image">
                 <div class="image-crop">
		                    <img id="avatar" src="https://drive.google.com/uc?id=1EVA3KUBLxCXF2EGmTf4LUB8F4yAvBrjl"></img>
	               </div>
              </div>
                <div class="card-title">
                    <h6 class="card-content">Mugilan</h6>
                    <h6 class="text-center">Android</h6>
                    <p class="card-center">Some quick example text to build.Some quick the example.<p>  
                </div>
             </div>
          </div>
        </div>

    </div>
  </div>
</div>

</div>
<script>
 $(".card").fadeIn("fast",function(){
      $(".card").fadeIn("fast", function(){
           // etc.
      });
   });
  </script>
  <script>
 $('.accordion-question').click(function() {
  if($(this).find('i').hasClass('fa-angle-down')){
      $('i').addClass('fa-angle-down');
      $(this).find('i').removeClass('fa-angle-down').addClass('fa-angle-up');
} else {
  $(this).find('i').addClass('fa-angle-down').removeClass('fa-angle-up');
}
});
    </script>
<?php
include("footer.php");
?>