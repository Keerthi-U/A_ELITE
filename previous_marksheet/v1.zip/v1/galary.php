<?php 
include_once('header.php');
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css" integrity="sha512-6lLUdeQ5uheMFbWm3CP271l14RsX1xtx+J5x2yeIDkkiBpeVTNhTqijME7GgRKKi6hCqovwCoBTlRBEC20M8Mg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css" integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
  
<style>
    .gallery-bg{
    background: url(images/hero.jpg) rgba(0, 0, 0, 0.5);
    background-blend-mode: overlay;
    height: 279px;

    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
    color: white;
    justify-content: cover;
    background-repeat: no-repeat;
    }
    .gellery-text {
    text-align: left;
    font-size: 28px;
    padding: 51px 12px 2px 11px;
    font-weight: 500;
    line-height: 1.2;
    color: #a18181;
    font-family:system-ui;}
.wrapper{
	width: 100%;

}

h1{
	font-family: "Trebuchet MS", Helvetica, sans-serif;
	font-size: 38px;
	text-align: center;
	
}

.effect-ming > div {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 2em;
    color: #ffeead;
}

.effect-ming > div > img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border: none;
}
.icon-zoom-in{
  font-size:30px;
}
/* .effect-ming img {
  display: block;
  height: auto;
  max-width: 100%;
} */

/* Grid */
.effect-ming{
    display: grid;
 
    position: relative;
    grid-gap: 5px;
   
    width: 33.33%;
    border: 10px solid #DADCDB;
  
    margin: 12px;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    grid-auto-rows: 125px;
    grid-auto-flow: dense;
}

.horizontal {
	grid-column: span 2;
}

.vertical {
    grid-row: 1 / span 2;
    grid-column: 2 / span 1;
}

.big {
	grid-column: span 2;
	grid-row: span 2;
}
img.img-dd {
    grid-row: 1 / span 3;
    grid-column: 1 / span 1;
}
.containerr {
    width: 100%;
    display: flex;
    margin: 0;
    margin-bottom: 3rem;
}
.horizontal1 {
    grid-column: span 3;
}


figure.effect-ming:hover img {
    opacity: 0.4;
}

figure.effect-ming img {
    opacity: 0.9;
    -webkit-transition: opacity 0.35s;
    transition: opacity 0.35s;
}
.tm-video-item img {
    position: relative;
    display: block;
    min-height: 100%;
    max-width: 100%;
    opacity: 0.8;
}
.img-fluid {
    max-width: 100%;
    width: 326px;
    height: auto;
}
figure.effect-ming:hover figcaption {
    background-color: rgba(58,52,42,0);
}
.tm-video-item figcaption, .tm-video-item figcaption > a {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
.tm-video-item figcaption {
    padding: 2em;
    color: #fff;
    text-transform: uppercase;
    font-size: 1.25em;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
}
.align-items-center {
    align-items: center!important;
}
 figcaption::before {
    position: absolute;
    top: 30px;
    right: 30px;
    bottom: 30px;
    left: 30px;
    border: 2px solid #fff;
    box-shadow: 0 0 0 30px rgb(255 255 255 / 20%);
    content: '';
    opacity: 0;
    -webkit-transition: opacity 0.35s, -webkit-transform 0.35s;
    transition: opacity 0.35s, transform 0.35s;
    -webkit-transform: scale3d(1.4,1.4,1);
    transform: scale3d(1.4,1.4,1);
}
figure.effect-ming h2 {
    font-size: 1.3em;
    opacity: 0;
    -webkit-transition: opacity 0.35s, -webkit-transform 0.35s;
    transition: opacity 0.35s, transform 0.35s;
    -webkit-transform: scale(1.5);
    transform: scale(1.5);
}

.tm-video-item h2, .tm-video-item p {
    margin: 0;
}
.tm-video-item h2 {
    word-spacing: -0.15em;
    font-weight: 300;
}
.tm-video-item figcaption::before, .tm-video-item figcaption::after {
    pointer-events: none;
}
.tm-video-item figcaption > a {
    z-index: 1000;
    text-indent: 200%;
    white-space: nowrap;
    font-size: 0;
    opacity: 0;
}

/* .tm-video-item figcaption, .tm-video-item figcaption > a {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
} */
.tm-video-item figcaption, .tm-video-item figcaption > a {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
.effect-ming:hover figcaption::before,
.effect-ming:hover h2 {
	opacity: 1;
 

	-webkit-transform: scale3d(1,1,1);
	transform: scale3d(1,1,1);
}

.effect-ming:hover figcaption { background-color:  #030c17; }
.effect-ming:hover img { opacity: 0.4; }  
  figcaption {
    /* background: rgba(0, 0, 0, 0.5);
    color: white;
    /* padding: 0.2em 0; */
    /* position: absolute; */
    /* top: 143px; */
    /* bottom: 0px;
    left: 0px;
    right: 0; */
    /* padding-bottom: 3px; */
    /* text-align: center;
    width: 100%; */ */
}

figure.effect-ming {
    /* background: #030c17; */
    
}
figure:hover{
  background: #030c17;
}


.figcaption2 {
  background: rgba(0, 0, 0, 0.5);
  color: white;
 
  padding: .2em 0;
  position: absolute;
  bottom: 0;
  text-align: center;
  width: 100%;
}

.figcaption2 span {
  font-size: 14px;
}

.figcaption3 {
  background: rgba(0, 0, 0, 0.5);
  color: white;
 
  padding: .2em 0;
  position: absolute;
  bottom: 0;
  text-align: center;
  width: 100%;
}

.figcaption3 span {
  font-size: 14px;
}
.figcaption4 {
  background: rgba(0, 0, 0, 0.5);
  color: white;
 
  padding: .2em 0;
  position: absolute;
  bottom: 0;
  text-align: center;
  width: 100%;
}

.figcaption4 span {
  font-size: 14px;
}


.zoom{
    width: 56px;
}
div#\#div2  {
    font-size: 16px;
    padding: 9px;
    color: white;
  
    text-transform: uppercase;
}
/* #menu:hover + .flyout {
    display: block;
} */
/* Media Queries */

@media screen and (min-width: 1024px){
	.wrapper{
		width: 90%;
		margin: 0 auto;
	}
}


/* slider css  */
.btn-danger {
  font-size: 16px;
}

.modal-backdrop.in {
  filter: alpha(opacity=80);
  opacity: .8;
}

.popup-image-gallery .modal-dialog {
  width: 100%;
}

.popup-image-gallery .modal-content {
  -webkit-box-shadow: none;
  box-shadow: none;
  background-color: transparent;
  border: 0;
  border-radius: 0;
}

.popup-slider-for {
  position: relative;
  min-height: 300px;
  z-index: 2;
}

@-webkit-keyframes spin {
  0% {
    -webkit-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}

@keyframes spin {
  0% {
    -webkit-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}

.popup-slider-for:after {
  content: "\e030";
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-animation: spin 1s linear infinite;
  animation: spin 1s linear infinite;
  z-index: -1;
  color: #fff;
  opacity: .75;
}

.popup-slider-for,
.main-image {
  text-align: center;
  margin-bottom: 0;
}

.popup-slider-for .slick-slide img {
  display: inline-block;
  max-width: 100%;
  vertical-align: middle;
}

.popup-slider-nav .thumbnail-image {
  position: relative;
  margin: 0 5px;
  cursor: pointer;
}

.popup-slider-nav .thumbnail-image,
.popup-slider-nav .thumbnail-image img {
  display: block;
  width: 140px;
  height: 100px;
}

.popup-slider-nav .thumbnail-image:after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  background-color: rgba(0, 0, 0, 0.6);
  -webkit-transition: all 0.2s linear;
  -moz-transition: all 0.2s linear;
  transition: all 0.2s linear;
}

.popup-slider-nav .thumbnail-image:hover:after {
  background-color: rgba(0, 0, 0, 0.4);
}

.popup-slider-nav .slick-current:after,
.popup-slider-nav .slick-current:hover:after,
.popup-slider-nav .slick-center:after,
.popup-slider-nav .slick-center:hover:after {
  background-color: transparent;
}

.pagingInfo {
  color: #fff;
  text-align: center;
  margin: 20px 0;
}

.popup-slider-for .slick-next,
.popup-slider-for .slick-prev {
  width: auto;
  height: auto;
  z-index: 1;
}

.popup-slider-for .slick-prev {
  left: 0;
}

.popup-slider-for .slick-prev:before,
.popup-slider-for .slick-next:before,
.popup-slider-for:after {
  font: normal normal 30px/1 'Glyphicons Halflings';
}

.popup-slider-for .slick-prev:before {
  content: "";
}

.popup-slider-for .slick-next:before {
  content: "";
}

.popup-slider-for .slick-next {
  right: 0;
}

.popup-image-gallery .close-icon {
  top: 0;
}

.slick-slide {
  outline: 0;
}

.close-btn {
  background-color: transparent;
  color: #fff;
  position: absolute;
  right: 30px;
  z-index: 3;
  font-size: 24px;
  margin: 0;
  opacity: .75;
}

.close-btn:hover,
.close-btn:focus {
  color: #fff;
  opacity: 10;
}

.popup-image-gallery .modal-dialog {
  margin: 0;
}

@media (max-width: 767px) {
  .popup-image-gallery .modal-body {
    padding: 0;
  }
  .popup-image-gallery .modal-dialog {
    margin-top: 20px;
  }
  .popup-image-gallery .close-icon {
    top: -20px;
  }
  .popup-slider-for .slick-prev {
    left: 12px;
  }
  .popup-slider-for .slick-next {
    right: 12px;
  }
}

/* my slider class */
.popup-image-gallery .modal-dialog {

    margin: auto;
}
.slick-next:before, .slick-prev:before {
    font-family: slick;
    font-size: 20px;
    line-height: 1;
    opacity: -0.25;
    color: #fff;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.fa.fa-angle-right,.fa-angle-left {
    color: white;
    /* border: 1px solid yellow; */
    font-size: 43px;
    padding: 17px;
    
}
h2.gly {
    text-align: center;
    font-size: 2.2rem;
    /* margin: 3rem 0 2rem; */
    text-transform: uppercase;
    letter-spacing: -0.02em;
    color: #fbebeb;
}
.popup-image-gallery .modal-content {
    -webkit-box-shadow: none;
    box-shadow: none;
    background-color: transparent;
    border: 0;
    border-radius: 0;
    margin-top: 34px;
}
img.img-dd {
    grid-row: 1 / span 3;
    grid-column: 1 / span 1;
    width: 577px;
    height: 421px;
    border:10px solid #DADCDB;
}
.close-btn {
    background-color: transparent;
    color: #fff;
    position: absolute;
    /* background: #ffdfdf; */
    right: 17px;
    z-index: 3;
    font-size: 24px;
    margin: 0;
    opacity: .75;
}
.slick-slide {
    /* width: 700px!important; */
}
</style>






</head>
<body>

<div class="gallery-imag">
    <div class="gallery-bg">
  <h2 class="gly">Gallery</h2>
    </div>
</div>
    <div class="wrapper">
        <h1 class="gellery-text">Latest Photos</h1>
        <div class="containerr">
          <figure class=" effect-ming tm-video-item wrapp ">
                <div class="horizontal">
                    <img src="images/img-13.jpg" class="img-dd" alt="img1">
                </div>
                <div>
                    <img src="images/img-16.jpg" class="img-dd" alt="img1">
                </div>
                <div>
                    <img src="images/img-11.jpg" class="img-dd" alt="img1">
                </div>
                
                <div class="figcaption2" id="#div2">
                    Image gallery
                </div>
                
                <figcaption class="d-flex align-items-center justify-content-center">
                    <h2><img src="images/zoom.png" class="zoom"></h2>
                    <a href="#" class="" data-toggle="modal" data-target="#popup-image-gallery" tabindex="0">
  
                     </a>
                </figcaption> 

     </figure>


       
         <figure class="effect-ming tm-video-item wrapp1">
           <!-- <div class="vertical"><img  src="https://picsum.photos/250/400" alt=""></div> -->
         
             <div class="img1">
                 <img src="https://picsum.photos/220/250" alt=""  class="img-dd">
             </div>
             <div class="img1">
                 <img src="https://picsum.photos/220/250" alt=""  class="img-dd">
             </div>
             <div class="img1">
                 <img src="https://picsum.photos/250/200" alt=""  class="img-dd">
             </div>
             <div class="horizontal1">
                 <img src="images/img-13.jpg" class="img-dd">
            </div>
            <div class="figcaption3" id="#div2">
                    Image gallery
            </div>
            <figcaption class="d-flex align-items-center justify-content-center">
                <h2><img src="images/zoom.png" class="zoom"></h2>
                <a href="#" class="" data-toggle="modal" data-target="#popup-image-gallery1" tabindex="0">
                </a>
           </figcaption> 
          
         </figure>

         <figure class="wrapp2 effect-ming tm-video-item">
            <div class="vertical">
              <img  src="https://picsum.photos/250/400" alt=""  class="img-dd">
            </div>
            <div>
              <img src="images/img-16.jpg" class="img-dd">
            </div>
            <div>
               <img src="images/img-16.jpg" class="img-dd">
            </div>
            <div class="figcaption4" id="#div2">
                    Image gallery
            </div>
            <figcaption class="d-flex align-items-center justify-content-center">
                <h2><img src="images/zoom.png" class="zoom"></h2>
                <a href="#" class="" data-toggle="modal" data-target="#popup-image-gallery2" tabindex="0"></a>
           </figcaption>
            
          </figure>

         </div>
    </div>


   

 
<!--     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<script>
 
//  $(document).ready(function(){
//   $("figure").hover(function(){
//     $("#div2").hide();
//   });
//   $("p").mouseleave(function(){
//     $("b").show();
//   });
// });
// $(document).ready(function(){
//   $(".d").mouseenter(function(){
//     $(".d1").hide();
//   });
//   $(".d").mouseleave(function(){
//     $(".d1").show();
//   });
// });
$(".wrapp").hover(function(){
    $('.figcaption2').hide();
},function(){
    $('.figcaption2').show();
});
$(".wrapp1").hover(function(){
    $('.figcaption3').hide();
},function(){
    $('.figcaption3').show();
});
$(".wrapp2").hover(function(){
    $('.figcaption4').hide();
},function(){
    $('.figcaption4').show();
});
  </script>
     <div class="modal popup-image-gallery" id="popup-image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <button type="button" class="btn close-btn" title="Close" data-dismiss="modal" aria-label="Close">&#10006;</span></button>
              <div class="popup-slider-for">
                <div class="main-image">
                <img src="images/img-16.jpg" class="img-dd">
                </div>
                <div class="main-image">
                <img src="images/img-13.jpg" class="img-dd">
                </div>
                <div class="main-image">
                <img src="images/img-15.jpg" class="img-dd">
                </div>
                <div class="main-image">
                <img src="images/img-10.jpg" class="img-dd">
                </div>
                <div class="main-image">
                <img src="images/img-11.jpg" class="img-dd">
                </div>
              </div>
              <h6 class="pagingInfo"></h6>
     
            </div>
          </div>
        </div>
    </div>

    <div class="modal popup-image-gallery" id="popup-image-gallery1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <button type="button" class="btn close-btn" title="Close" data-dismiss="modal" aria-label="Close">&#10006;</span></button>
              <div class="popup-slider-for">
                <div class="main-image">
                  <img src="https://unsplash.it/340/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/360/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/380/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/400/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/420/?random" alt=""  class="img-dd">
                </div>
              </div>
              <h5 class="pagingInfo"></h5>
              <div class="popup-slider-nav hidden-xs">
                <!-- <div class="thumbnail-image">
                  <img src="https://unsplash.it/340/?random" alt="">
                </div>unsplash.it
                <div class="thumbnail-image">
                  <img src="https://unsplash.it/360/?random" alt="">
                </div>
                <div class="thumbnail-image">
                  <img src="https://unsplash.it/380/?random" alt="">
                </div>
                <div class="thumbnail-image">
                  <img src="https://unsplash.it/400/?random" alt="">
                </div>
                <div class="thumbnail-image">
                  <img src="https://unsplash.it/420/?random" alt="">
                </div> -->
              </div>
            </div>
          </div>
        </div>
    </div>
    <div class="modal popup-image-gallery" id="popup-image-gallery2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <button type="button" class="btn close-btn" title="Close" data-dismiss="modal" aria-label="Close">&#10006;</span></button>
              <div class="popup-slider-for">
                <div class="main-image">
                  <img src="https://unsplash.it/340/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/360/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/380/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/400/?random" alt=""  class="img-dd">
                </div>
                <div class="main-image">
                  <img src="https://unsplash.it/420/?random" alt=""  class="img-dd">
                </div>
              </div>
              <h5 class="pagingInfo"></h5>
              <div class="popup-slider-nav hidden-xs">
                <!-- <div class="thumbnail-image">
                  <img src="https://unsplash.it/340/?random" alt="">
                </div>unsplash.it
                <div class="thumbnail-image">
                  <img src="https://unsplash.it/360/?random" alt="">
                </div>
                <div class="thumbnail-image">
                  <img src="https://unsplash.it/380/?random" alt="">
                </div>
                <div class="thumbnail-image">
                  <img src="https://unsplash.it/400/?random" alt="">
                </div>
                <div class="thumbnail-image">
                  <img src="https://unsplash.it/420/?random" alt="">
                </div> -->
              </div>
            </div>
          </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.js" integrity="sha512-WNZwVebQjhSxEzwbettGuQgWxbpYdoLf7mH+25A7sfQbbxKeS5SQ9QBf97zOY4nOlwtksgDA/czSTmfj4DUEiQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    
    <!-- slider-1 -->
     <script>
  $('#popup-image-gallery').on('shown.bs.modal', function() {
  $('.popup-slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,

    autoplay:true,
            arrows: true,
            prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
            nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    fade: true,
    asNavFor: '.popup-slider-nav',
    // adaptiveHeight: true,
  });
  $('.popup-slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.popup-slider-for',
    dots: false,
    arrows: false,
    focusOnSelect: true,
    variableWidth: true,
    centerMode: true,
    infinite: true,
  });
});
// Slick.js: Get current and total slides (ie. 3/5)
var $status = $('.pagingInfo');
var $slickElement = $('.popup-slider-for');

$slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide) {
  //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
  var i = (currentSlide ? currentSlide : 0) + 1;
  $status.text(i + '/' + slick.slideCount);
});




// slider-2
$('#popup-image-gallery1').on('shown.bs.modal', function() {
  $('.popup-slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,

    autoplay:true,
            arrows: true,
            prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
            nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    fade: true,
    asNavFor: '.popup-slider-nav',
    // adaptiveHeight: true,
  });
  $('.popup-slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.popup-slider-for',
    dots: false,
    arrows: false,
    focusOnSelect: true,
    variableWidth: true,
    centerMode: true,
    infinite: true,
  });
});
// Slick.js: Get current and total slides (ie. 3/5)
var $status = $('.pagingInfo');
var $slickElement = $('.popup-slider-for');

$slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide) {
  //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
  var i = (currentSlide ? currentSlide : 0) + 1;
  $status.text(i + '/' + slick.slideCount);
});

// Slick slider sync situation
// var slides = $(".popup-slider-for .slick-track > .slick-slide").length;
// $('.popup-slider-for').on('afterChange', function(event, slick, currentSlide, nextSlide) {
//   var inFocus = $('.popup-slider-for .slick-current').attr('data-slick-index');
//   $('.popup-slider-nav .slick-current').removeClass('slick-current');
//   $('.popup-slider-nav .slick-slide[data-slick-index="' + inFocus + '"]').trigger('click');
// });



// slider-3
$('#popup-image-gallery2').on('shown.bs.modal', function() {
  $('.popup-slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,

    autoplay:true,
            arrows: true,
            prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
            nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    fade: true,
    asNavFor: '.popup-slider-nav',
    // adaptiveHeight: true,
  });
  $('.popup-slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.popup-slider-for',
    dots: false,
    arrows: false,
    focusOnSelect: true,
    variableWidth: true,
    centerMode: true,
    infinite: true,
  });
});
// Slick.js: Get current and total slides (ie. 3/5)
var $status = $('.pagingInfo');
var $slickElement = $('.popup-slider-for');

$slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide) {
  //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
  var i = (currentSlide ? currentSlide : 0) + 1;
  $status.text(i + '/' + slick.slideCount);
});

// Slick slider sync situation
// var slides = $(".popup-slider-for .slick-track > .slick-slide").length;
// $('.popup-slider-for').on('afterChange', function(event, slick, currentSlide, nextSlide) {
//   var inFocus = $('.popup-slider-for .slick-current').attr('data-slick-index');
//   $('.popup-slider-nav .slick-current').removeClass('slick-current');
//   $('.popup-slider-nav .slick-slide[data-slick-index="' + inFocus + '"]').trigger('click');
// });
   </script>
<?php 
include_once('footer.php');
?>
