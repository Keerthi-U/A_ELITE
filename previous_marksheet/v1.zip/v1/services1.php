

<?php
include_once('header.php');
?>
<link rel="stylesheet" href="style.css"> 

<style>
.hight-pra {
    padding: 9px;
    font-weight: 600;
}
.highlight {
    background: #ededed;
    margin-bottom: 45px;
    padding-bottom: 11px;
}
.high-head {
    display: flex;
}.high-head {
    display: flex;
}
span.h-text {
    padding: 12px 8px 0px 7px;
    font-weight: 600;
    color: #ad0000;
}
img.sc {
    width: 65px;
}
.activites {
    
    background: #f7f7f7;
    margin-bottom: 91px;
    margin-top: 108px;

}
.act-head >h3 {
   
    font-size: 28px;
    color: #000;
    line-height: 14px;
    text-align:center;
    font-family: 'Raleway';
    font-weight: 600;
    position: relative;
    margin-bottom: 15px;
    text-transform: uppercase;
    margin-top: 15px;
    font-weight: 100;
}
.act-head {
    margin: 52px 0px 0px 0px;
}
.service-heading {
    margin: 25px 0 15px 0;
}
.service-heading {
    font-size: 18px;
    color: #000;
    line-height: 21px;
    font-weight: 600;
    text-transform: none;
}
.sericeact-text{
    color: #707070;
    font-size: 15px;
    line-height: 21px;
}
p.large {
    color: #898989;
    font-size: 14px;
    text-align:center;
    font-weight: 400;
    margin: 0 0 36px 0;
}
.full {
    margin-bottom: 34px;
}
.bg-relif {
    background:url('images/relif.jpg') rgba(0, 0, 0, 0.5);
    background-blend-mode: overlay;;
    width: 471px;
    height: 651px;
}
.high-heading {
    padding: 30px 3px 5px 37px;
    border: none;
    border: 1;
    border-bottom: 2px solid;
}
.nav-link:hover {
  opacity: 1;
}

.service-heading::before {
  transition: 300ms;
  height: 5px;
  content: "";
  position: absolute;
  background-color: #031D44;
}

.nav-link-ltr::before {
  width: 0%;
  bottom: 10px;
}
.hight-pra1 {
    padding: 13px 12px;
    background: #ebcbcb;
}
    .h-text2 {
    margin-left: 12px;
    font-weight: 600;
    color: #872a2a;
}
b.dis {
    color: #a70909;
}
img.himg2 {
    width: 28px;
    margin-top: -2px;
   
}
.note{
    margin-bottom: 61px;
}
.dis::after{
    content:"\003A";
    padding-left: 6px;
    padding-right: 11px;

}

.s_card1 {
    box-shadow: 1px 2px 16px hsl(0deg 0% 61% / 25%);
    margin: 12px;
    /* background: #c7c7c7; */
    padding: 8px;
}
.ser-card {
    display: flex;

}
.s_card1 {
    box-shadow: 1px 2px 16px hsl(0deg 0% 61% / 25%);
    margin: 12px;
    /* background: #c7c7c7; */
    padding: 8px;
    width: 20%;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
}
.s_head {
    font-weight: 700;
}
p.ser-texrr {
    color: #565656;
    font-size: 13px;
}
.ser-card {
    display: flex;
    margin-left: 100px;
    margin-right: 100px;
}
img.himg3 {
    width: 21px;
    margin-top: -6px;
}
span.h-textex {
    color: #a91414;
    font-size: 15px;
}
.link {
    color: #007bff;
    text-decoration: none;
}

/* register popup css */
.popup-btn{
	/* position: absolute!important;
	top: 55%;
	left: 50%;
	transform: translate(-50%,-50%); */
}
.main-btn-rect,
.main-btn-circle{
	/* position: relative;
	margin: 0;
	font-family: 'Roboto', sans-serif;
	color: #FFFFF0;
	background-color: rgb(252, 79, 79);
	text-transform: uppercase;
	font-size: 25px;
	letter-spacing: 1px;	
	outline: none;
	cursor: pointer;
	z-index: 100; */
}
.main-btn-rect {
	/* padding: 10px 80px;
	line-height: 30px; */
    border:none;
}
.main-btn-rect:before, 
.main-btn-rect:after{
  position: absolute;
  content: '';
  top:0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 240, 0.2);
  -webkit-transition: width 0.3s;
  -o-transition: width 0.3s;
  transition: width 0.3s;
}
.main-btn-rect:before {
  left: 0;
}
.main-btn-rect:after {
  right: 0;
}
.main-btn-rect:hover:before, 
.main-btn-rect:hover:after{
  width: 50%;
}
.main-btn-circle{
	/* height: 40px;
	width: 40px;
	-webkit-border-radius: 50%;
	border-radius: 100%;
	line-height: 40px;
  -webkit-transition: box-shadow 0.3s;
  -o-transition: box-shadow 0.3s;
  transition: box-shadow 0.3s; */
}
.main-btn-circle:hover{   
  -webkit-box-shadow: inset 2px 1px 0px 20px rgba(255, 255, 240, 0.2);
  -moz-box-shadow: inset 2px 1px 0px 20px rgba(255, 255, 240, 0.2);
  box-shadow: inset 2px 1px 0px 20px rgba(255, 255, 240, 0.2);
}
.popup{
  position: fixed;
	top: 100%;
  width: 100%;
  height: 100%;
  z-index: 10001;
}
.popup.active{
  top:0;
  background-color: rgb(68 68 68 / 77%);
  transition: background-color .6s ,opacity .6s;
}
.popup .main-btn-rect{
  padding: 10px 100px;
}
.popup .popup-content{
  position: absolute;
  top: 50%;
  left: 50%;
  max-height: 568px;
  min-width: 59%;
  margin-top: 150px;
  padding: 25px;
  background-color: white;
  color: #070000;
  -webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
  -ms-transform: translateX(-50%) translateY(-50%);
  transform: translateX(-50%) translateY(-50%);
  -webkit-transform: translateX(-50%) translateY(-50%);
  -moz-transform: translateX(-50%) translateY(-50%);
  -o-transform: translateX(-50%) translateY(-50%);
  transition: margin .6s;
  -webkit-transition: margin .6s;
  -moz-transition: margin .6s;
  -o-transition: margin .6s;
}
input[type=file]{
    background-color: transparent!important;
    border: none!important;
    margin-left: -7px;
    padding: 0!important;
}
.form-control input:focus + label,
.form-control input:valid + label{
  font-size: 11px;
  top: -5px
}
.popup.active .popup-content{
  margin-top: 0px;
}
.popup-content h6{
  display: table;
  font-size: 16px;
  text-align: center;
  border-radius: 16px;
  margin: 13px auto;
  font-family: 'Roboto',sans-serif;
  text-transform: uppercase;
  font-weight: 500;
}
.form-group{
	position: relative;
	width: 90%;
	margin: 0px auto;
}
form#send input, form#send textarea{
	position: relative;
    margin-bottom: 0px;
    width: 100%;
    font-size: 14px;
    height: 29px;
    font-family: 'RobotoLight', sans-serif;
    text-indent: 20px;
    background-color: rgb(237 240 245 / 25%);
	outline: 0;
	border: none;
	border-bottom: 1px solid red;
	-webkit-transition: border 0.6s;
	-o-transition: border 0.6s;
	transition: border 0.6s;
    
}
form#send input:focus ,
form#send textarea:focus{
	border: 1px solid rgb(63, 173, 168)!important; 
    border:none;
    box-shadow:none!important;
}
 input:focus ~ .floating-label
 input:not(:focus):valid ~ .floating-label{
  top: 8px;
  bottom: 10px;
  left: 20px;
  font-size: 11px;
  opacity: 1;
}
form#send label{
	position: absolute;
	/* top: 0;
	line-height: 28px; */
	-webkit-transition: color .5s;
	-o-transition: color .5s;
	transition: color .5s;
}
.form-control {
    border: 1px solid #e5e5e5!important;
    padding: 19px 12px;
    width: 100%;
 
    box-shadow: none;

    display: block;
    BORDER-RADIUS: 0PX !important;
}
form#send input:focus + label,
form#send textarea:focus + label{
  color: rgb(63, 173, 168);
}
form#send .txt{
	line-height: 22px;
	left: 2px;
}
form#send .main-btn-rect {
	position: relative;
    display: block;
    padding: 11px 66px;
    margin: 0px auto;
    font-size: 14px;
    position: relative;
    /* margin: 0; */
    font-family: 'Roboto', sans-serif;
    color: #FFFFF0;
    background-color: rgb(252, 79, 79);
    text-transform: uppercase;
    font-size: 14px;
    letter-spacing: 1px;
    outline: none;
    cursor: pointer;
    z-index: 100;
}
form#send .main-btn-rect i {
	margin-right: 5px;
}
.popup .fade-out {
    position: absolute;
    top: -14px;
    right: -22px;
    color: white;
    font-weight: 800;
    text-align: center;
    font-size: 15px;
}
.share-wrap{
	position: absolute;
  display: inline-table;
	top: 67%;
	left: 50%;
	transform: translate(-50%, -50%);
  padding: 15px;
  text-align: center;
}
.share-btn{
  color: #FFFFF0;
  padding: 7px 25px;
  text-decoration: none;
  cursor: pointer;
  font-weight: 100;
  font-size: 14px;
  font-family:'Lobster', sans-serif;
  background-color: rgba(63, 173, 168, .8);
  text-transform: uppercase;
  border-radius: 5px;
  transition: background-color .5s;
  -webkit-transition: background-color .5s;
  -moz-transition: background-color .5s;
  -o-transition: background-color .5s;
}
.share-btn:hover{
  color: #FFFFF0;
  text-decoration: none;
  background-color: rgba(63, 173, 168, 1.0);
}

.resp-sharing-button__link,
.resp-sharing-button__icon {
  display: inline-block
}
.resp-sharing-button__link {
  text-decoration: none;
  color: #fff;
  margin: 2px;
}
.resp-sharing-button {
  border-radius: 5px;
  transition: 25ms ease-out;
  padding: 6px 9px;
  transition: background-color .5s;
  -webkit-transition: background-color .5s;
  -moz-transition: background-color .5s;
  -o-transition: background-color .5s;
}
.resp-sharing-button__icon svg {
  width: 1em;
  height: 1em;
  margin-right: 0.4em;
  vertical-align: top
}
.resp-sharing-button--small svg {
  margin: 0;
  vertical-align: middle
}
.resp-sharing-button__icon,
.resp-sharing-button__icon--solid,
.resp-sharing-button__icon--solidcircle {
  fill: #fff;
  stroke: none
}
.resp-sharing-button--facebook {
  background-color: #3b5998;
  border-color: #3b5998;
}
.resp-sharing-button--facebook:hover,
.resp-sharing-button--facebook:active {
  background-color: #2d4373;
  border-color: #2d4373;
}
.resp-sharing-button--twitter {
  background-color: #55acee;
  border-color: #55acee;
}
.resp-sharing-button--twitter:hover,
.resp-sharing-button--twitter:active {
  background-color: #2795e9;
  border-color: #2795e9;
}
.resp-sharing-button--linkedin {
  background-color: #0077b5;
  border-color: #0077b5;
}
.resp-sharing-button--linkedin:hover,
.resp-sharing-button--linkedin:active {
  background-color: #046293;
  border-color: #046293;
}
@media only screen and (max-width: 768px){
  h1 {font-size: 25px;}
  h2 {font-size: 14px;}
  form#send .main-btn-rect {padding: 7px 60px; font-size: 14px;}
  .popup-btn{padding: 7px 60px; font-size: 14px;}
}
 .field-wrapper{
            position: relative;
            /* margin-bottom: 15px; */
        }
		
        .field-wrapper input{
            border: 1px solid #DADCE0;
            /* padding: 15px; */
            border-radius: 4px;
            width: 100%;
        }

        .field-wrapper .field-placeholder{
            font-size: 15px;
    position: absolute;
    /* background: #fff; */
    bottom: 0px;
    text-indent: 20px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #80868b;
    left: 8px;
    padding: -1px 8px;
    -webkit-transition: transform 150ms cubic-bezier(0.4,0,0.2,1),opacity 150ms cubic-bezier(0.4,0,0.2,1);
    transition: transform 150ms cubic-bezier(0.4,0,0.2,1),opacity 150ms cubic-bezier(0.4,0,0.2,1);
    z-index: 1;
    text-align: left;
    width: 100%;
        }        
        
        .field-wrapper .field-placeholder span{
            background: #ffffff;
            padding: 0px 8px;
        }
.field-wrapper input:not([disabled]):focus~.field-placeholder
        {
            color:#1A73E8;
        }
		
        .field-wrapper input:not([disabled]):focus~.field-placeholder,
        .field-wrapper.hasValue input:not([disabled])~.field-placeholder
        {
            -webkit-transform: scale(.75) translateY(-39px) translateX(-60px);
            transform: scale(.75) translateY(-28px) translateX(-53px);
            
            
        }
 </style>

<div class="bg_img_sec">
        <div class="bg_services">
         <div class="ser_img_tit">
             <h2>Our Services</h2>
             <p>Lorem Ipsum is simply dummy text of the
                 <br>
                  printing and typesetting industry. Lorem
                   
                 into electronic typesetting,</p>
         </div>

        </div>
    </div>

    <!-- <div class="serviced">
    <div class="sub_titile">
     <h5>Employment / Job Placements (In IT SECTOR, SHOE AND TEXTILE INDUSTRY)</h5>
     </div>
    <div class="ser-card">
        <div class="s_card1">
                   <div class="s_head"> Career Counselling</div>
                   <p  class="ser-texrr">Lorem Ipsum is simply dummy text of the</p>
                 
        </div>
        <div class="s_card1">
                   <div class="s_head">Career Counselling</div>
                   <p  class="ser-texrr">Lorem Ipsum is simply dummy text of the</p>
                  
        </div>
        <div class="s_card1">
                   <div class="s_head">Career Counselling</div>
                   <p  class="ser-texrr">Lorem Ipsum is simply dummy text of the</p>
                  
        </div>
        <div class="s_card1">
                   <div class="s_head">Career Counselling</div>
                   <p  class="ser-texrr">Lorem Ipsum is simply dummy text of the</p>
                  
        </div>
        <div class="s_card1">
                   <div class="s_head">Career Counselling</div>
                   <p  class="ser-texrr">Lorem Ipsum is simply dummy text of the</p>
                  
        </div>
  

    </div>
</div> -->
<div class="container">

    <div class="services_page">
    <div class="ser_head">
  <h2> Un-Employed & young job aspirants</h2>
  </div>
<div class="service_section"> 
<div class="service_content">
     <div class="sub_titile">
     <h5>Employment / Job Placements (In IT SECTOR, SHOE AND TEXTILE INDUSTRY)</h5>
     </div>
     <div class="ser_list">
      
        <div class="tree" style="padding:0px;">
          <div class="one1">Career Counselling
          <li class="two">two</li>
          <li class="two">three</li>
          </div>
        </div>
        <div class="tree" style="padding:0px;">
            <div class="one1">Resume Tips
            <li class="two">two</li>
            <li class="two">three</li>
            </div>
        </div>
        <div class="tree" style="padding:0px;">
            <div class="one1">Interview Preparation (Mock Interview)
            <li class="two">two</li>
            <li class="two">three</li>
            </div>
        </div>
        <div class="tree" style="padding:0px;">
            <div class="one1">Accessing Candidate Job fitment
            <li class="two">two</li>
            <li class="two">three</li>
            </div>
        </div>
        <div class="tree" style="padding:0px;">
            <div class="one1">Providing training if required<
            <li class="two">two</li>
            <li class="two">three</li>
            </div>
        </div>

      
     </div>
 </div>
</div>
<div class="service_section">
 <div class="service_content">
     <div class="sub_titile">
     <h5>Placement Training</h5>
     </div>
     <div class="ser_list">
            
        <div class="tree" style="padding:0px;">
          <div class="one1">Soft skills Training
          <li class="two">two</li>
          <li class="two">three</li>
          </div>
        </div>
        <div class="tree" style="padding:0px;">
            <div class="one1">Craftsmanship Training
            <li class="two">two</li>
            <li class="two">three</li>
            </div>
        </div>
        <div class="tree" style="padding:0px;">
            <div class="one1">Tailoring Training
            <li class="two">two</li>
            <li class="two">three</li>
            </div>
        </div>
        <div class="tree" style="padding:0px;">
            <div class="one1">Driver Training
            <li class="two">two</li>
            <li class="two">three</li>
            </div>
        </div>
        <div class="tree" style="padding:0px;">
            <div class="one1">Mechanic Training
            <li class="two">two</li>
            <li class="two">three</li>
            </div>
        </div>
     </div>
 </div>
</div>
<div class="service_section">
 <div class="service_content">
     <div class="sub_titile">
     <h5>Employment Registration / TNPSC / UPSC Exam </h5>
     </div>
     <div class="ser_list">
        <div class="tree" style="padding:0px;">
            <div class="one1">Online Employment registration support for TN Govt & Union Govt
             <li class="two">two</li>
             <li class="two">three</li>
            </div>
        </div>
        <div class="tree" style="padding:0px;">
          <div class="one1">Online application submission support for TNPSC / UPSC Exam 
          <li class="two">two</li>
          <li class="two">three</li>
          </div>
        </div>

    
     </div>
 </div>
</div> 
 </div>








  <div class="highlight">
       <!-- <div class="high-heading">
           <h2>Disclaimer</h2>
       </div> -->

    <div class="high-head">
   
 
    <div class="hight-pra">
       <img src="images/icons8-star-20.png" class="himg" >  </div><span class="h-text"> To avail above services,Please Register@
        I MAN FORUM, <span class="h-textex">Your service will be provided based on the availability <button  class="link main-btn-rect popup-btn"  data-popup="popup-reg">Click here </a></span></span>
   
        </div>

        <div class="high-head">
   
 
    <div class="hight-pra">
       <img src="images/icons8-star-20.png" class="himg" >  </div><span class="h-text">All services are offered  subject to terms & conditions of the  I MAN FORUM </span>
   
        </div>
        <div class="high-head">
   
 
    <!-- <div class="hight-pra">
       <img src="images/icons8-star-20.png" class="himg" >  </div><span class="h-text">Disclaimer: I MAN Forum does not guarantee Job, but it will only act as a facilitator to get a Job.</span> -->
   
        </div>
       
</div> 
<div class="hight-pra1">
       <img src="images/danger.png" class="himg3" > <span class="h-text2"><b class="dis">Disclaimer</b>  I MAN Forum does not guarantee Job, but it will only act as a facilitator to  get a job </span> </div>
   
        </div>
</div>


 <!-- Activities  -->

 <section class="activites">
     <div class="row">
          <div class="col-md-12">
          <!-- <div class="act-head">
              <h3>I MAN FORUM other initiatives towards Charitable & Relief activities</h3>
          </div> -->
         </div>
     </div>
     <div class="container-fluid">
    
     <div class="row">
         <div class="col-md-12">
          <div class="act-head">
              <h3>Relief activities</h3>
              <p class="large">I MAN FORUM other initiatives towards Charitable  </p>
          </div>
             <div class="row">
                 <div class="col">
                   <div class="full">
                     <div class="icon text-center">
                       <img src="images/scholarship.png" class="sc">
                       <h4 class="service-heading underline">Scholarship to students</h4>
                       <p class="sericeact-text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo.</p>
                     </div>
                   </div>
                 </div>
                 <div class="col">
                 <div class="full text-center">
                       <img src="images/flooded-house.png" class="sc">
                       <h4 class="service-heading">Flood relief</h4>
                       <p class="sericeact-text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo.</p>
                   </div>
                 </div>
                 <div class="col">
                 <div class="full text-center">
                       <img src="images/dinner.png" class="sc">
                       <h4 class="service-heading">Food pack distribution</h4>
                       <p class="sericeact-text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo.</p>
                   </div>
                 </div>
                 <div class="col">
                 <div class="full text-center">
                       <img src="images/medical-assistance.png" class="sc">
                       <h4 class="service-heading">Medical Assistance</h4>
                       <p class="sericeact-text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo.</p>
                   </div>
                 </div>
                 <div class="col">
                 <div class="full text-center">
                       <img src="images/Aadhar.png" class="sc">
                       <h4 class="service-heading">Aadhaar Card changes / Correction facilities</h4>
                       <p class="sericeact-text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo.</p>
                   </div>
                 </div>
                 <!-- <div class="col-md-4">
                 <div class="full">
                       <img src="images/Aadhar.png" class="sc">
                       <h4 class="service-heading">Any other initiatives…</h4>
                       <p class="sericeact-text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo.</p>
                   </div>
                 </div> -->
               
             </div>
         </div>
         <!-- <div class="col-md-4">
             <div class="relif-imag">
                 <div class="bg-relif">

                 </div>
             </div>
         </div> -->
        </div>
     

     </div>

  

 </section>
<div class="container note">
<div class="hight-pra1">
       <img src="images/edit (2).png" class="himg2" > <span class="h-text2"><b class="dis">NOTE</b>We Accept donation for all our charitable & Employment related activities, interested can contact I MAN office.  </span> 
</div>
</div>



<div id="popup-reg" class="popup">
  <div class="popup-content">
    <div class="event-header">
      <h6>Registration</h6>
    </div>
  
    <form id="send" class="send-form">
           <div class="form-group row">
                <div class=" col-md-6 field-wrapper">
         
                <input type="text"  class="form-control" id="name" name="name" >
                <label class="field-placeholder"><span>Name</span></label>
                  
                 
               </div>
            <div class=" col-md-6  field-wrapper" >
              
                <input type="text" class="form-control"  id="address" name="address" >
                <label class="field-placeholder"><span>Address</span></label>
                  
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6  field-wrapper">
                
                <input type="tel"  class="form-control" id="phone" name="phone">
                <label class="field-placeholder"><span>Phone No</span></label>
                  
            </div>
            <div class="col-md-6  field-wrapper">
        
            <input type="text"  class="form-control" id="name" name="name">
            <label class="field-placeholder"><span>Aadhar No</span></label>
                  
          </div>
       </div>
        <div class="form-group row">
            <div class="col-md-6  field-wrapper">
         
            <input type="text" class="form-control" id="name" name="name">
            <label class="field-placeholder"><span>Qualification</span></label>
            
        </div>
            <div class="col-md-6  field-wrapper">
          
            <input type="text" id="mail" class="form-control" name="mail" >
            <label class="field-placeholder"><span>Skill set</span></label>
        </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6  field-wrapper">
           
            <input type="text" class="form-control" id="name" name="name">
            <label class="field-placeholder"><span>Area of Interest</span></label>
        </div>
            <div class="col-md-6  field-wrapper">
            <label for="mail">
            </label>
            <input type="email" class="form-control"  id="mail" name="mail">
            <label class="field-placeholder"><span>Family Background</span></label>
        </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6  field-wrapper">
            <label for="name">
            </label>
            <input type="file" id="name" class="form-control" name="name" >
           
        </div>
           
        </div>

   
        <button type="submit" class="main-btn-rect" name="text" class="form-control" value="Send">
          <i class="fa fa-paper-plane"></i>Submit</button>
      </form>
  

    <span class="fade-out main-btn-circle">╳</span>
  </div>
</div>


<?php
include_once('footer.php');
?>

<script>
$(function() {
    $('.tree .tree:has(.one1)').addClass('parent');
    $('.tree .one1').click(function() {
        var thistree = $(this);
        thistree.children('.two').slideToggle('slow');
        thistree.filter('.parent').toggleClass('expanded');
        return false;
    });
});
</script>
<script>
    $(document).ready(function(){
  $('.popup-btn').click(function(){ 
    var popupBlock = $('#'+$(this).data('popup'));
    popupBlock.addClass('active')
      .find('.fade-out').click(function(){
        popupBlock.css('opacity','0').find('.popup-content').css('margin-top','350px');        
        setTimeout(function(){
          $('.popup').removeClass('active');
          popupBlock.css('opacity','').find('.popup-content').css('margin-top','');
        }, 600);
      });
 });
});
$(function () {

$(".field-wrapper .field-placeholder").on("click", function () {
    $(this).closest(".field-wrapper").find("input").focus();
});
$(".field-wrapper input").on("keyup", function () {
    var value = $.trim($(this).val());
    if (value) {
        $(this).closest(".field-wrapper").addClass("hasValue");
    } else {
        $(this).closest(".field-wrapper").removeClass("hasValue");
    }
});

});
    </script>