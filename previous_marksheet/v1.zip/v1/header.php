<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="media.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;1,400&family=Roboto:wght@300;500&display=swap" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>
        <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->



    <!-- Latest compiled JavaScript -->
    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
</head>
<style>
    *{
    box-sizing: border-box;
}

body{
    font-family: 'Roboto', sans-serif;
    margin: 0;
    background-color:#fff;
    overflow-x: hidden;
}

/* Estilos del NavBar */
.tophead {
    background-color: white;
    overflow: hidden;
    background: #fbfbfb;
    border-bottom: 1px solid #eee;
  display:flex;
  justify-content:space-around;
  padding: 0;
}
/* a.social-media {
    color: grey;
    font-size: 15px;
    border-left: 1px solid #eee;
    padding: 15px;
} */
a.menu-item-1:hover{
    color:#fff;
    background-color:#3B5998;
  
}
a.menu-item-2:hover{
    color:#fff;
    background-color:#4285F4;
  
}
a.menu-item-3:hover{
    color:#fff;
    background-color:#0e76a8;
  
}
a.menu-item-4:hover{
    color:#fff;
    background-color:#4ddbff;
  
}
a.menu-item-5:hover{
    color:#fff;
    background-color: #80d4ff;
  
}
a.menu-item-6:hover{
    color:#fff;
    background-color:#FF0000;
  
}
.site-header {
    padding: 0px 0;
    background-color: #fff;
    transition: padding 0.2s ease-in-out 0s;
    clear: both;
    z-index: 999;
    position: relative;
   text-decoration: inherit;
}
/* .nav-link a {
    color: #568c11;
    text-decoration: inherit;

} */
.nav-link{
    color: #222;
    font-size: 18px;
    font-family: "Montserrat", sans-serif;
    padding-right: 1.5rem;
}
.site-title {
    color: #568c11;
    font-family: 'Montserrat', sans-serif;
    font-size: 28px;
    margin: 3px;
}
.navbar-expand-sm .navbar-nav .nav-link {
    padding-left: 0.5rem!important;
    padding-right: 1.5rem!important;
    font-family: 'Montserrat', sans-serif!important;
    font-size: 15px;
}

img.img-logo {
    width: 100%;
}
a.custom-button.doante-now {
    float: right;
    margin: -18px 0 0 20px;
    padding: 8px 17px;
    text-align: center;
    min-width: inherit;
    text-transform: capitalize;
    /* background-color: #568c11; */
    text-transform: capitalize;
    color: #fff;
    text-decoration: none;
    font-family: "Montserrat", sans-serif;
    background: linear-gradient( 
45deg, #dc2323 10%, #8c1112 90%);
    font-weight: 600;
}
.header-social-wrapper ul li a{
    border-right: 1px solid #eee;
    color: grey;
    font-size: 15px;
    border-left: 1px solid #eee;
    padding: 14px;
    text-decoration: none;
}
.header-social-wrapper1 ul li a{
    border-right: 1px solid #eee;
    color: #8c1112;
    font-size: 15px;
    border-left: 1px solid #eee;
    padding: 14px;
    text-decoration: none;
}
/* .header-social-wrapper1 {
    display: flex;
    justify-content: end;
} */
/* i#faa {
    padding: 2px;
} */
i#faa {
    padding: 10px;
    font-size: 16px;
}
/* .sticky.is-sticky {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    z-index: 1000;
    width: 100%;
} */

/* nav {
  background: #eaebec;
  min-height: 85px;
} */
/* #navbarCollapse {
    justify-content: center;
    color: #222;
    justify-content: space-around;
    font-size: 15px;
    font-weight: normal;
    padding: 15px 15px;
    position: relative;
    z-index: 99;
    font-weight: 500;
    font-family: "Montserrat", sans-serif!important;
    font-weight: 500;
} */
#navbarCollapse ul li a:hover{
color:#568c11;

}

 ul li   a:after {    
  background: none repeat scroll 0 0 transparent;
  bottom: 0;
  content: "";
  display: block;
  height: 2px;
  left: 50%;
  position: absolute;
  background: #fff;
  transition: width 0.3s ease 0s, left 0.3s ease 0s;
  width: 0;
}

.carousel-indicators li {
    box-sizing: content-box;
    -ms-flex: 0 1 auto;
    flex: 0 1 auto;
    width: 30px;
    height: 7px;
    margin-right: 3px;
    margin-left: 3px;
    text-indent: -999px;
    cursor: pointer;
    background-color: #fff;
    background-clip: padding-box;
    border-top: 10px solid transparent;
    border-bottom: 10px solid transparent;
    opacity: .5;
    transition: opacity .6s ease;
}
#main-slider .cycle-prev:hover, #main-slider .cycle-next:hover {
    background-color: #9cc900;
    color: #fff;
    border-color: #9cc900;
}
.site-header {
    /* padding: 16px 0; */
    padding: 4px 0;
    background-color: #fff;
    transition: padding 0.2s ease-in-out 0s;
    clear: both;
    z-index: 999;
    position: relative;
   text-decoration: inherit;
}
/* .nav-link a {
    color: #568c11;
    text-decoration: inherit;

} */
.nav-link{
    color: #222;
    font-size: 18px;
    font-family: "Montserrat", sans-serif;
    padding-right: 1.5rem;
}
.site-title {
    color: #568c11;
    font-family: 'Montserrat', sans-serif;
    font-size: 28px;
    margin: 3px;
}
.navbar-expand-sm .navbar-nav .nav-link {
    padding-left: 0.5rem!important;
    padding-right: 1.4rem!important;
    font-family: 'Montserrat', sans-serif!important;
    font-size: 15px;
}
img.img-logo {
    width: 100%;
}
.site-header {
    padding: 4px 0;
    background-color: #fff;
    transition: padding 0.2s ease-in-out 0s;
    clear: both;
    z-index: 999;
    position: relative;
   text-decoration: inherit;
}
/* .nav-link a {
    color: #568c11;
    text-decoration: inherit;

} */
.nav-link{
    color: #222;
    font-size: 18px;
    font-family: "Montserrat", sans-serif;
    padding-right: 1.5rem;
}
.site-title {
    color: #568c11;
    font-family: 'Montserrat', sans-serif;
    font-size: 28px;
    margin: 1px;

}
.navbar-expand-sm .navbar-nav .nav-link {
    padding-left: 0.5rem!important;
    padding-right: 1.5rem!important;
    font-family: 'Montserrat', sans-serif!important;
    font-size: 15px;
}
img.img-logo {
    width: 100%;
}
a.custom-button.doante-now {
    float: right;
    margin: -18px 0 0 20px;
    padding: 6px 13px;
    text-align: center;
    min-width: inherit;
    text-transform: capitalize;
    background-color: #568c11;
    text-transform: capitalize;
    color: #fff;
    text-decoration: none;
    font-family: "Montserrat", sans-serif;
}
.navbar-toggler-icon {
  border-color: rgb(255,102,203);
} 
.navbar-toggler-icon{
background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(255,102,203, 0.5)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E");
}
img.log_g {
    width: 266px;
}
.img_d{
    width: 30px;
    height: 30px;
    margin-right: 10px;
}
a.custom-button.doante-now {
    display: flex;
}
.donate_text {
    margin-bottom: 0px;
    padding-top: 4px;
    font-size: 15px;
}
.sticky-top {
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    z-index: 1020;
    /* box-shadow: 0 0 18px rgb(0 0 0 / 40%); */
    z-index: 801;
    -webkit-box-shadow: 0 8px 6px -6px  rgb(0 0 0 / 40%);
    -moz-box-shadow: 0 8px 6px -6px  rgb(0 0 0 / 40%);
    box-shadow: 0 8px 6px -6px rgb(0 0 0 / 40%);
    transform: translate3D(0, 0, 0);}
    #navbarCollapse ul li a:hover{
       color: red;  
    } 
#navbarCollapse ul li a:after
    {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  width: 0%;
  content: '';
  /* color: transparent; */
  /* background: red; */
  height: 1px;

}
#navbarCollapse ul li a:hover:after {
  width: 100%;
}
/* #navbarCollapse ul li a:hover{
color:#d93e3e;
border-bottom: 2px solid #d93e3e;
} */
a, a > .navs {
  position: relative;
  color: inherit;
  text-decoration: none;
  line-height: 24px;
}
a:before, a:after {
  content: '';
  position: absolute;
  transition: transform .5s ease;
}
.navs {
  padding-top: 10px;
}
.navs:before {
    left: 6px;
    bottom: 0;
    width: 73%;
    height: 4px;
    background: #ed4646;
    transform: scaleX(0);
}
.navs:hover:before {
  transform: scaleX(1);
}
.custom-button.doante-now {
    border-radius: 14px;
}
.donate_text:hover{
    color:white;
}
#navbarCollapse ul li .custom-button:hover{

    color:white;
}
a#\31 {
    color: #ae1819;
    text-decoration: none;
}
  </style>
<body>


<div class="navbar navbar-expand-sm sticky-top  tophead">
  <!-- Brand/logo -->
  <div class="header-social-wrapper">
  <ul class="navbar-nav" id="menu-item">
    <li class="nav-item">
      <a href="#" class="social-media menu-item-1"><i class="fa fa-facebook-f"></i></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-2"><i class="fa fa-twitter"></i></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-3"><i class="fa fa-linkedin"></i></a>
    </li>
    <!-- <li class="nav-item">
      <a  href="#" class="social-media  menu-item-4"><i class="fa fa-wordpress"></i></a>
    </li> -->
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-5"><i class="fa fa fa-instagram"></i></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media  menu-item-6"><i class="fa fa-youtube"></i></a>
    </li>
  </ul>
</div>
 
<div class="header-social-wrapper1">
<ul class="navbar-nav" id="menu-itemss">
    <li class="nav-item">
      <a href="#" class="social-media1"><i class="fa fa-phone" id="faa"></i><span>+91 9677463675</span></a>
    </li>
    <li class="nav-item">
      <a href="#" class="social-media1"><i class="fa fa-whatsapp" id="faa"></i><span>+91 7200863675</span></a>
    </li>
    <li class="nav-item">
      <a  href="#" class="social-media1"><i class="fa fa-envelope" id="faa"></i> <span> imantrust21@gmail.com </span></a>
    </li>
    <!-- <li class="nav-item">
      <a  href="#" class="social-media1"><i class="fa fa-globe" id="faa"></i><span>#257, Bazaar street, (opp.Charminar st) 
Pernambut</span></a> -->
    </li>
 
  </ul>
</div>
</div>

<!--top header-->
<header class="sticky-top">
            <!--most top info -->
         
            <!-- End most top info -->
            <nav class="navbar navbar-white navbar-expand-sm  site-header ">
        <div class="container">
        <a href="#" class="navbar-brand"><p class="site-title"> <img src="images/man.png" class="log_g"></p></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
     <div id="navbarCollapse" class="collapse navbar-collapse navbar-right nav-menus">
        <ul class="navbar-nav ms-auto" id="menu-items" >
            <li class="nav-item navbar-right">
                <a href="index.php" class="nav-link  navs active">
                    Home
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="About_Us.php" class="nav-link navs active">
                   About Us
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="services1.php" class="nav-link navs active">
                Services
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="gallery2.php" class="nav-link navs active">
                Gallery
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="volunteers.php" class="nav-link navs active">
                    Volunteers
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="news.php" class="nav-link navs active">
             News
                </a>
            </li>
            <li class="nav-item navbar-right">
                <a href="contact_us.php" class="nav-link navs active">
            Contact Us
                </a>
            </li>
            <li class="nav-item navbar-right nvv">
                <a href="" class="nav-link">
                <a href="#" class="custom-button doante-now"><img src="images/solidarity.png" class="img_d"><p class="donate_text">Donate</p></a>
                </a>
            </li>
          
           
        </ul>
        </div>
      </div>
   </header>
        <!-- End top header-->


 

